"""Revisión de fuentes realmente incrustadas, página y archivos de toda la colección."""
from pathlib import Path
import fitz,json
R=Path(__file__).resolve().parents[1];D=json.loads((R/'lecciones.json').read_text());bad=[];pages=0;fonts=[]
for lesson in D:
 p=R/'descargas'/(lesson['key']+'.pdf');doc=fitz.open(p);pages+=len(doc);names=set();xrefs=set()
 for i,page in enumerate(doc):
  if len(page.get_text().strip())<45:bad.append([p.name,i,'página vacía'])
  for font in doc.get_page_fonts(i):
   names.add(font[3])
   if 'KaTeX' in font[3]:xrefs.add(font[0])
  for b in page.get_text('dict')['blocks']:
   for line in b.get('lines',[]):
    for s in line['spans']:
     x0,y0,x1,y1=s['bbox']
     if min(x0,y0)<-1 or x1>page.rect.width+1 or y1>page.rect.height+1:bad.append([p.name,i,s['text'][:30],'fuera de página'])
 if not any('KaTeX_Main' in n for n in names):bad.append([p.name,'sin fuente matemática principal'])
 if any(not doc.extract_font(xref)[3] for xref in xrefs):bad.append([p.name,'fuente sin incrustar'])
 fonts.append({'ejercicio':lesson['id'],'fuentes_matematicas':sorted(n for n in names if 'KaTeX' in n)})
assert not bad,bad[:20]
book=fitz.open(R/'Coleccion_1_4.pdf');assert len(book)==pages+4
report={'version':'1.4.2','individuales':len(D),'paginas_individuales':pages,'paginas_general':len(book),'paginas_guia':len(fitz.open(R/'Guia_1_4.pdf')),'limites_y_paginas_vacias':'sin incidencias','fuentes_incrustadas':fonts,'composicion_KaTeX':'sin errores en los 76 documentos','revision_visual':'matrices de 2, 3, 5 y 7 filas, vectores, radicales, fracciones, fórmulas, demostraciones, figuras, guía e índice','compilacion_LaTeX':'Fuente editable incluida. El PDF se genera con sintaxis LaTeX y KaTeX con sus fuentes incrustadas; no se requiere instalar LaTeX para consultarlo.'}
(R/'tests/resultados_documentos.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'PDF':76,'paginas':len(book),'fuentes_incrustadas':'76/76','incidencias':len(bad)},ensure_ascii=False))
