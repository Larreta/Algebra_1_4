"""Contrastes exactos independientes de la presentación y sus botones."""
import sys,json,itertools
from pathlib import Path
import sympy as S
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from motor.modelo import M,value
from motor.matlab_lecciones import nil_index,order
D=json.loads((ROOT/'lecciones.json').read_text());by={d['id']:d for d in D}
assert len(D)==76 and len({d['key'] for d in D})==76
assert [sum(d['group']==g for d in D) for g in ['practicos','teoricos','matlab']]==[25,40,11]
checked=0;products=0
for d in D:
 assert d['steps'] and d['answer']
 if d['group']=='teoricos':assert d['proof'] and len(d['steps'])>=4
 for case in d['cases']:
  if case.get('error'):
   assert d['id']=='8' and 'interiores' in case['error'];continue
  for n in case['nodes']:
   a=[M(x['rows']) for x in n['inputs']];op=n['op'];R=M(n['result']['rows'])
   E=a[0]*a[1] if op=='mul' else a[0]+a[1] if op=='add' else a[0]-a[1] if op=='sub' else a[0].T if op=='transpose' else value(n['k'])*a[0] if op=='scale' else a[0]
   if n['binary']:E=E.applyfunc(lambda x:x%2)
   assert S.simplify(R-E)==S.zeros(*R.shape),(d['id'],case['name'],n['name'])
   for q in n['cells']:
    i,j=q['i'],q['j'];assert S.simplify(value(q['value'])-R[i,j])==0
    if op=='mul':
     acc=S.Integer(0)
     for k,p in enumerate(q['pairs']):
      assert value(p['a'])==a[0][i,k] and value(p['b'])==a[1][k,j]
      prod=S.simplify(a[0][i,k]*a[1][k,j]);assert S.simplify(value(p['product'])-prod)==0
      assert S.simplify(value(p['before'])-acc)==0;acc=S.simplify(acc+prod)
      assert S.simplify(value(p['after'])-acc)==0;products+=1
     assert S.simplify(value(q['raw'])-acc)==0
    checked+=1
   assert len(n['cells'])==R.rows*R.cols
  assert M(case['result']['rows'])==M(case['nodes'][-1]['result']['rows'])
# Resultados solicitados, calculados también fuera del árbol de operaciones.
def result(id,ci=0):return M(by[str(id)]['cases'][ci]['result']['rows'])
assert result(2)==M([[-2,34],[24,-9]])
assert result(10)==S.zeros(2) and result(11)==result(11,1)==M([[8,-6],[-8,6]])
assert result(12)==S.eye(2) and result(15)==M([[3],[3]])
assert result(16)==result(16,1)==M([[1]])
for n,st in [(18,['3/8','5/8']),(19,['3/7','4/7']),(20,['21/53','24/53','8/53']),(21,['10/37','12/37','15/37'])]:
 A=M(by[str(n)]['matrices'][0]['rows']);x=M([[s] for s in st]);assert A*x==x and sum(x)==1 and all(a>=0 for a in x)
 assert all(sum(A[:,j])==1 for j in range(A.cols))
for n,target in [('T.39',S.zeros(2)),('T.40',S.eye(2))]:
 cs=by[n]['cases'];assert len(cs)==16;assert sum(M(c['result']['rows'])==target for c in cs)==4
 candidates=[S.Matrix(2,2,bits) for bits in itertools.product([0,1],repeat=4)]
 assert sum((a*a).applyfunc(lambda x:x%2)==target for a in candidates)==4
assert result(24)==result(25)==S.zeros(2)
for n,size,k in [('ML.9',3,4),('ML.10',4,4),('ML.11',5,8)]:assert order(S.Matrix(size,size,lambda i,j:1 if i<=j else 0),True)==k
A=M(by['ML.4']['matrices'][0]['rows']);pi=M([['5/22','3/11','1/2']]);assert pi*A==pi
assert nil_index(S.zeros(7))==1
for j in [2,4,6]:
 B=S.zeros(7);B[0,j]=1;assert nil_index(B)==2
# Fórmulas cerradas de ML.5 y ML.6, incluso k=0.
for n in [5,6]:
 A=M(by['ML.'+str(n)]['matrices'][0]['rows']);a,b,d=A[0,0],A[0,1],A[1,1]
 for k in range(13):assert A**k==M([[a**k,b*(a**k-d**k)/(a-d)],[0,d**k]])
report={'ejercicios':len(D),'casillas_verificadas':checked,'productos_verificados':products,'resultado':'correcto','metodo':'aritmética simbólica exacta y comprobaciones independientes; ejemplos no sustituyen las pruebas formales'}
(ROOT/'tests/resultados_matematicos.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
