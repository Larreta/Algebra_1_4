"""Regenera datos exactos, códigos y una página autónoma sin conexión."""
from pathlib import Path
import sys,json,gzip,base64,re
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from motor import practicos,teoricos,matlab_lecciones

def inline_fonts(css):
 def convert(m):
  name=m.group(1)
  return 'src:url(data:font/woff2;base64,'+base64.b64encode((ROOT/'vendor'/name).read_bytes()).decode()+') format("woff2")'
 result=re.sub(r'src:url\((fonts/[^)]+\.woff2)\) format\("woff2"\)[^;}]*',convert,css)
 assert result.count('@font-face')==css.count('@font-face')==20,'Se alteraron las reglas de fuentes matemáticas'
 assert len(re.findall(r'url\(data:font/woff2;base64,',result))==20
 assert 'src:url(fonts/' not in result
 return result

def page(data):
 template=(ROOT/'motor/plantilla.html').read_text()
 packed=base64.b64encode(gzip.compress(json.dumps(data,ensure_ascii=False,separators=(',',':')).encode(),mtime=0)).decode()
 assets=json.loads((ROOT/'descargas/manifest.json').read_text()) if (ROOT/'descargas/manifest.json').exists() else {'general':{'url':'descargas/Coleccion_1_4.pdf'},'exercises':{d['key']:{'url':'descargas/'+d['key']+'.pdf'} for d in data}}
 replacements={'KATEX_CSS':inline_fonts((ROOT/'vendor/katex.min.css').read_text()),'STYLE':(ROOT/'motor/diseno.css').read_text(),'KATEX_JS':(ROOT/'vendor/katex.min.js').read_text(),'PLOTLY':(ROOT/'vendor/plotly.min.js').read_text(),'PLOTLY_ES':(ROOT/'vendor/plotly-es.js').read_text(),'FFLATE':(ROOT/'vendor/fflate.js').read_text(),'DATA':"JSON.parse(fflate.strFromU8(fflate.gunzipSync(Uint8Array.from(atob('"+packed+"'),c=>c.charCodeAt(0)))))",'DOWNLOADS':json.dumps(assets,ensure_ascii=False),'APP':(ROOT/'motor/app.js').read_text()}
 for key,val in replacements.items():template=template.replace('/*'+key+'*/',val)
 (ROOT/'index.html').write_text(template)

def main():
 data=practicos.build()+teoricos.build()+matlab_lecciones.build()
 for d in data:
  if d['id'] in ['9','13','14','24','25']:
   d['statement']+=' Incisos: '+'; '.join(c['name'] for c in d['cases'] if not c.get('exploration'))+'.'
  if d['id'] in ['T.8','T.9']:
   d['matrices']=[d['steps'][0]['matrices'][0]]
 assert len(data)==76 and len({d['key'] for d in data})==76
 (ROOT/'lecciones.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')))
 for d in data:
  if d.get('matlab'):(ROOT/'matlab'/d['matlab']['filename']).write_text(d['matlab']['code'])
 page(data)
 print(f'{len(data)} ejercicios; index.html: {(ROOT/"index.html").stat().st_size/1048576:.2f} MiB')
if __name__=='__main__':main()
