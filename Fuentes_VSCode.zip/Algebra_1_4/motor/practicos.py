"""Los 25 prácticos de las imágenes. Se calculan con racionales exactos."""
from .modelo import *
from .eliminacion import elim
R=S.Rational

def closed_case(name,e,binary=False,goal='',plot=None):return make_case(name,e,binary,goal,plot)
def eq_cases(label,left,right,binary=False):return [closed_case(label+' · lado izquierdo',left,binary,goal='Calculamos este lado sin utilizar de antemano la identidad que queremos verificar.'),closed_case(label+' · lado derecho',right,binary,goal='Calculamos el otro lado de forma independiente y comparamos sus entradas.')]
def evaluate_case(c):return M(c['result']['rows']) if 'result' in c else None

def steady_steps(A,x0,labels,include_limit=False):
 n=A.rows;syms=['p','q','u'][:n];sysrows=[list((A-S.eye(n)).row(i))+[0] for i in range(n)]+[[1]*n+[1]]
 raw,_,meta=elim(sysrows,syms);st=M([[v] for v in meta['solucion']]);steps=[p('Qué significa una distribución estable','Buscamos proporciones que no cambien al pasar un año. No basta con resolver Ax=x: también exigimos que las proporciones sumen 1 y sean no negativas.',math=[r'A\mathbf{x}=\mathbf{x},\quad '+ '+'.join(syms)+'=1',r'\mathbf{x}\geq\mathbf{0}'])]
 for item in raw:
  if item['titulo'].startswith(('Primero:','Nuestro plan:')):continue
  math=item.get('formulas',[])
  if item.get('sistema'):math=math+[r'\begin{cases}'+r'\\'.join(item['sistema'])+r'\end{cases}']
  actions=[{'text':a['explica'],'math':a.get('formula','')} for a in item.get('acciones',[])]
  if item.get('tabla'):
   table={'headers':item['tabla']['cabeceras'],'rows':item['tabla']['filas']}
  else:table=None
  steps.append(p('Equilibrio · '+item['titulo'],item['texto'],math=math,actions=actions,table=table,conclusion=item.get('conclusion','')))
 steps.append(p('Comprobamos que son proporciones válidas','Todas las entradas son no negativas y su suma es exactamente uno. Relacionamos las coordenadas con las compañías, en el mismo orden del enunciado.',math=[tex(st),r'\mathbf{1}^T\mathbf{x}='+tex(sum(st))],conclusion='; '.join(f'{name}: {st[i]} = {float(st[i])*100:.4f} %' for i,name in enumerate(labels))))
 if include_limit:
  P=A if all(v>0 for v in A) else A*A;h=1 if P==A else 2;delta=min(P);epsilon=n*delta
  steps += [p('Por qué el equilibrio describe el largo plazo','Una aproximación numérica no demuestra convergencia. Usaremos una estimación que obliga al error a disminuir. La norma 1 de un vector es la suma de los valores absolutos de sus coordenadas. Una matriz no negativa cuyas columnas suman 1 no puede aumentar esa norma.',math=[r'\|\mathbf{v}\|_1=\sum_i|v_i|',r'\|A\mathbf{v}\|_1\leq\sum_i\sum_j a_{ij}|v_j|=\sum_j|v_j|=\|\mathbf{v}\|_1']),
   p('Encontramos una parte positiva común a todas las columnas',f'Tomamos P=A^{h}. Todas sus entradas son positivas. Su menor entrada es δ={delta}; definimos ε={n}δ={epsilon}. U es la matriz con todas las entradas iguales a 1/'+str(n)+'. Al retirar esa parte uniforme queda otra matriz Q no negativa con columnas que suman 1.',matrices=[mat('P',P)],math=[r'P=\varepsilon U+(1-\varepsilon)Q,\qquad\varepsilon='+tex(epsilon),r'Q=\frac{P-\varepsilon U}{1-\varepsilon}']),
   p('El error se contrae y tiende a cero','Si dos distribuciones suman 1, la suma de las coordenadas de su diferencia es cero. Por ello U anula esa diferencia. Como Q no aumenta la norma 1, cada bloque de '+str(h)+' años reduce el error por el factor 1−ε, que está entre 0 y 1.',math=[r'U(\mathbf{v}-\mathbf{x})=\mathbf{0}',r'\|P^k\mathbf{v}-\mathbf{x}\|_1\leq(1-\varepsilon)^k\|\mathbf{v}-\mathbf{x}\|_1\longrightarrow0'],conclusion='En los años intermedios A tampoco aumenta el error. Por tanto toda distribución inicial converge al equilibrio calculado. Si hubiera dos equilibrios, esta misma desigualdad obligaría a que su diferencia fuera cero: el equilibrio es único.')]
 return st,steps

def markov(id,A,x0,labels,statement,years,claimed=None):
 cases=[];previous=x0
 for y in range(1,years+1):
  c=closed_case(f'(a) Año {y}: x{y} = A x{y-1}',mul(N('A',A),N('x'+str(y-1),previous)),goal='Una columna de A describe de dónde venían los clientes; una fila indica a qué compañía llegan. Calculamos una contribución por origen y las sumamos.',plot={'kind':'markov','year':y,'labels':labels,'initial':[float(v) for v in x0]});cases.append(c);previous=evaluate_case(c)
 st,steps=steady_steps(A,x0,labels,include_limit=id in (20,21))
 if claimed is not None:assert st==claimed
 cases.append(closed_case('(b) Verificamos A x* = x*',mul(N('A',A),N('x*',st)),goal='La distribución estable se obtuvo resolviendo el sistema. Aquí verificamos todas sus componentes por multiplicación.',plot={'kind':'markov','year':'stable','labels':labels,'initial':[float(v) for v in x0],'stable':[float(v) for v in st]}))
 c=Compiler();v=x0
 for y in range(1,21):
  v,_=c.run(mul(N('A',A),N('x'+str(y-1),v)));c.nodes[-1]['year']=y
 extra={'name':'Exploración opcional · 20 años','nodes':c.nodes,'result':mat('x20',v),'binary':False,'exploration':True,'goal':'Cada matriz-vector representa un año. El gráfico solo incorpora un año cuando terminamos todas sus componentes.','plot':{'kind':'markov','initial':[float(x) for x in x0],'stable':[float(x) for x in st],'labels':labels}}
 cases.append(extra)
 initial=[p('Leemos el modelo antes de calcular','Las columnas corresponden a las compañías de origen y las filas a las de destino. Por ejemplo, la entrada de fila 1 y columna 2 indica la parte de clientes de la compañía 2 que pasa a la compañía 1. Cada columna suma 1: los clientes se reparten, no desaparecen.',math=[r'\mathbf{x}_{t+1}=A\mathbf{x}_t',r'\sum_i a_{ij}=1\quad\text{para cada columna }j']),p('Qué significa multiplicar A por una distribución','Para obtener la nueva participación de una compañía, sumamos lo que recibe desde cada origen. Un porcentaje multiplicado por una proporción inicial da su contribución al total.',math=[r'(\mathbf{x}_{t+1})_i=\sum_j a_{ij}(\mathbf{x}_t)_j'])]
 # Los cálculos de los años se presentan antes del equilibrio.
 d=lesson(id,'Distribución del mercado y equilibrio',statement,{'A':A,'x0':x0},cases=[],steps=initial,answer='Equilibrio: '+str(list(st))+'.',graph={'kind':'markov','labels':labels})
 d['cases']=cases
 for i,c in enumerate(cases[:years]):d['steps']+=case_steps(c,i)
 d['steps']+=steps+case_steps(cases[years],years)
 if id in (20,21):
  winner=max(range(A.rows),key=lambda i:st[i]);d['steps'].append(p('(c) Interpretamos el mercado a largo plazo','Comparamos las proporciones exactas del equilibrio. El término «mayor parte» se interpreta aquí como la mayor participación entre las compañías; no implica necesariamente superar el 50 %.',math=[tex(st)],conclusion=f'La compañía {labels[winner]} tendrá la participación mayor: {st[winner]}, aproximadamente {float(st[winner])*100:.2f} %.'))
 d['steady']=rows(st);return d

def build():
 L=[]
 A=M([[1,2,-2],[3,4,5]]);B=M([[2,0,1],[3,-2,5]]);C=M([[-4,-6,1],[2,3,0]]);a,b,c=N('A',A),N('B',B),N('C',C)
 cs=eq_cases('(a) Conmutatividad',add(a,b),add(b,a))+eq_cases('(b) Asociatividad',add(a,add(b,c)),add(add(a,b),c))+[closed_case('(c) Neutro aditivo',add(a,N('O',S.zeros(2,3)))),closed_case('(d) Construimos −A',scale(-1,a)),closed_case('(d) Comprobamos A+(−A)',add(a,scale(-1,a)))]
 L.append(lesson(1,'Las cuatro propiedades de la suma','Verifique el teorema 1.1 para las matrices A, B y C dadas.',{'A':A,'B':B,'C':C},cs,steps=[p('Qué vamos a verificar','El teorema reúne cuatro afirmaciones: cambiar el orden de dos sumandos; cambiar la agrupación de tres; sumar la matriz cero; y sumar el opuesto. Calcularemos cada lado, no supondremos que ya coinciden.',math=[r'A+B=B+A',r'A+(B+C)=(A+B)+C',r'A+O=A',r'A+(-A)=O'])],answer='Se verifican los cuatro incisos. El neutro es la matriz cero 2×3 y el único opuesto de A es −A.'))
 A=M([[1,3],[2,-1]]);B=M([[-1,3,2],[1,-3,4]]);C=M([[1,0],[3,-1],[1,2]])
 L.append(lesson(2,'Asociatividad del producto','Verifique el inciso (a) del teorema 1.2 para A, B y C dadas.',{'A':A,'B':B,'C':C},eq_cases('A(BC)=(AB)C',mul(N('A',A),mul(N('B',B),N('C',C))),mul(mul(N('A',A),N('B',B)),N('C',C))),steps=[p('Agrupar no significa cambiar el orden','En ambos lados los factores conservan el orden A, B, C. Solo cambia qué producto calculamos primero. A es 2×2, B es 2×3 y C es 3×2; los dos caminos terminan en 2×2.')],answer='Los dos caminos dan '+str((A*B*C).tolist())+'.'))
 A=M([[1,-3],[-3,4]]);B=M([[2,-3,2],[3,-1,-2]]);C=M([[0,1,2],[1,3,-2]])
 L.append(lesson(3,'Distribuir un producto sobre una suma','Verifique el inciso (b) del teorema 1.2 para las matrices dadas.',{'A':A,'B':B,'C':C},eq_cases('A(B+C)=AB+AC',mul(N('A',A),add(N('B',B),N('C',C))),add(mul(N('A',A),N('B',B)),mul(N('A',A),N('C',C)))),answer='Ambos lados son '+str((A*(B+C)).tolist())+'.'))
 A=M([[4,2],[1,-3]]);B=M([[0,2],[-4,3]]);a,b=N('A',A),N('B',B)
 cs=eq_cases('(a) r(sA)=(rs)A',scale(6,scale(-2,a)),scale(-12,a))+eq_cases('(b) (r+s)A=rA+sA',scale(4,a),add(scale(6,a),scale(-2,a)))+eq_cases('(c) r(A+B)=rA+rB',scale(6,add(a,b)),add(scale(6,a),scale(6,b)))
 L.append(lesson(4,'Tres propiedades del producto por escalares','Verifique los incisos (a), (b) y (c) del teorema 1.3 para r=6, s=−2 y las matrices dadas.',{'A':A,'B':B},cs,answer='Las tres igualdades se cumplen entrada por entrada.'))
 A=M([[1,3],[2,-1]]);B=M([[-1,3,2],[1,-3,4]]);a,b=N('A',A),N('B',B)
 L.append(lesson(5,'Dónde puede colocarse un escalar','Verifique el inciso (d) del teorema 1.3 para r=−3 y las matrices A y B dadas.',{'A':A,'B':B},[closed_case('A(rB)',mul(a,scale(-3,b))),closed_case('r(AB)',scale(-3,mul(a,b))),closed_case('(rA)B',mul(scale(-3,a),b))],steps=[p('Conservamos el orden de las matrices','El número −3 puede actuar sobre el segundo factor, sobre el producto o sobre el primero. En los tres caminos A permanece antes de B.',math=[r'A(rB)=r(AB)=(rA)B'])],answer='Los tres resultados son '+str((-3*A*B).tolist())+'.'))
 A=M([[1,3,2],[2,1,-3]]);B=M([[4,2,-1],[-2,1,5]]);a,b=N('A',A),N('B',B)
 L.append(lesson(6,'La transpuesta respeta la suma y el escalar','Verifique los incisos (b) y (d) del teorema 1.4 para r=−4 y las matrices dadas.',{'A':A,'B':B},eq_cases('(b) (A+B)ᵀ=Aᵀ+Bᵀ',T(add(a,b)),add(T(a),T(b)))+eq_cases('(d) (rA)ᵀ=rAᵀ',T(scale(-4,a)),scale(-4,T(a))),answer='Se verifican ambos incisos; los resultados tienen tamaño 3×2.'))
 B=M([[3,-1],[2,4],[1,2]]);b=N('B',B)
 L.append(lesson(7,'Transponer un producto invierte el orden','Verifique el inciso (c) del teorema 1.4 para A y B dadas.',{'A':A,'B':B},eq_cases('(AB)ᵀ=BᵀAᵀ',T(mul(a,b)),mul(T(b),T(a))),steps=[p('La inversión del orden es necesaria','Al transponer, las columnas del producto pasan a ser filas. Por eso el factor que estaba a la derecha aparece primero en el nuevo producto. Comprobamos ambos caminos sin reemplazar uno por el otro.')],answer='Los dos lados dan '+str((A*B).T.tolist())+'.'))
 common={'A':M([[2,1,-2],[3,2,5]]),'B':M([[2,-1],[3,4],[1,-2]]),'C':M([[2,1,3],[-1,2,4],[3,1,0]]),'D':M([[2,-1],[-3,2]]),'E':M([[1,1,2],[2,-1,3],[-3,2,-1]]),'F':M([[1,0],[2,-3]])};a,b,c,d,e,f=[N(k,common[k]) for k in 'ABCDEF']
 cs=[closed_case('(a) (AB)ᵀ',T(mul(a,b))),closed_case('(b) BᵀAᵀ',mul(T(b),T(a))),closed_case('(c) AᵀBᵀ',mul(T(a),T(b))),closed_case('(d) B(Bᵀ)ᵀ',mul(b,T(T(b)))),closed_case('(e) BᵀB',mul(T(b),b))]
 L.append(lesson(8,'Compatibilidad y productos con transpuestas','De ser posible, calcule (a) (AB)ᵀ; (b) BᵀAᵀ; (c) AᵀBᵀ; (d) BBᵀᵀ; (e) BᵀB.',common,cs,note='En (d), la doble T se lee como (Bᵀ)ᵀ=B. Por tanto se está intentando formar BB.',answer='(a) y (b) coinciden. (c) y (e) están definidos. (d) no está definido: 3×2 por 3×2.'))
 cs=[closed_case('(a) (3C−2E)ᵀB',mul(T(sub(scale(3,c),scale(2,e))),b)),closed_case('(b) Aᵀ(D+F)',mul(T(a),add(d,f))),closed_case('(c) BᵀC+A',add(mul(T(b),c),a)),closed_case('(d) (2E)Aᵀ',mul(scale(2,e),T(a))),closed_case('(e) (Bᵀ+A)C',mul(add(T(b),a),c))]
 L.append(lesson(9,'Expresiones compuestas: primero los paréntesis','De ser posible, calcule las cinco expresiones indicadas, usando las matrices comunes de los ejercicios 8 y 9.',common,cs,answer='Los cinco incisos están definidos; cada desarrollo conserva sus paréntesis y dimensiones.'))
 A=M([[-2,3],[2,-3]]);B=M([[3,6],[2,4]]);a,b=N('A',A),N('B',B)
 L.append(lesson(10,'Un producto cero con factores no nulos','Demuestre que AB=O para A y B dadas.',{'A':A,'B':B},[closed_case('AB',mul(a,b))],steps=[p('Qué hay que demostrar','Una matriz es cero solo si todas sus entradas son cero. Por ello debemos justificar las cuatro cuentas del producto. Los factores no son cero, lo cual muestra que la regla de los números reales «producto cero implica factor cero» no se traslada sin más a las matrices.')],answer='AB=O₂×₂, aunque A≠O y B≠O.'))
 B=M([[-1,3],[2,0]]);C=M([[-4,-3],[0,-4]]);b,c=N('B',B),N('C',C)
 L.append(lesson(11,'La cancelación de matrices puede fallar','Demuestre que AB=AC para las matrices dadas.',{'A':A,'B':B,'C':C},[closed_case('AB',mul(a,b)),closed_case('AC',mul(a,c)),closed_case('A(B−C)',mul(a,sub(b,c)))],steps=[p('No cancelamos A sin una hipótesis adicional','Calcularemos AB y AC por separado. B y C son distintas: que ambos productos coincidan no permite concluir B=C. La verificación de A(B−C)=O explicará lo sucedido.')],answer='AB=AC='+str((A*B).tolist())+', pero B≠C.'))
 A=M([[0,1],[1,0]])
 L.append(lesson(12,'Dos intercambios recuperan la identidad','Demuestre que A²=I₂ para A dada.',{'A':A},[closed_case('A²',power(N('A',A),2))],steps=[p('Qué significa A²','Se multiplica A por A con la regla fila por columna. No se eleva al cuadrado cada casilla. Esta matriz intercambia las dos coordenadas; dos intercambios recuperan el vector original.')],answer='A²=I₂.'))
 for id,A in [(13,M([[4,2],[1,3]])),(14,M([[1,-1],[2,3]]))]:
  a=N('A',A);I=N('I₂',S.eye(2))
  exprs=[('(a) A²+3A',add(power(a,2),scale(3,a))),('(b) 2A³+3A²+4A+5I₂',add(add(add(scale(2,power(a,3)),scale(3,power(a,2))),scale(4,a)),scale(5,I)))] if id==13 else [('(a) A²−2A',sub(power(a,2),scale(2,a))),('(b) 3A³−2A²+5A−4I₂',sub(add(sub(scale(3,power(a,3)),scale(2,power(a,2))),scale(5,a)),scale(4,I)))]
  L.append(lesson(id,'Evaluar un polinomio de matrices','Determine las expresiones matriciales de los incisos (a) y (b) para la matriz A dada.',{'A':A},[closed_case(n,e) for n,e in exprs],steps=[p('Un número constante se convierte en un múltiplo de la identidad','Primero calculamos las potencias con productos matriciales. Luego multiplicamos por los coeficientes y sumamos o restamos posiciones iguales. El término constante es 5I₂ o −4I₂, no una matriz llena de cincos o de menos cuatro.')],answer='Los resultados de ambos incisos se muestran al terminar sus cuentas.'))
 A=M([[2,1],[1,2]]);x=M([[1],[1]])
 L.append(lesson(15,'Encontrar el factor Ax=rx','Determine un escalar r tal que Ax=rx para A y x dados.',{'A':A,'x':x},[closed_case('Ax',mul(N('A',A),N('x',x)))],steps=[p('Qué representa r','Buscamos un solo número que multiplique a todas las coordenadas del vector x. Como x=(1,1)ᵀ, el vector rx es (r,r)ᵀ.',math=[r'A\mathbf{x}=r\mathbf{x}'])],answer='r=3. Las dos componentes de Ax son 3.',graph={'kind':'vector2','initial':[1,1],'target':[3,3]}))
 A=M([[-2],[1],[-1]]);k=S.sqrt(6)/6
 cs=[closed_case('Comprobamos k=√6/6',mul(T(scale(k,N('A',A))),scale(k,N('A',A)))),closed_case('Comprobamos k=−√6/6',mul(T(scale(-k,N('A',A))),scale(-k,N('A',A))))]
 L.append(lesson(16,'Normalizar un vector: conservar los dos signos','Determine una constante k tal que (kA)ᵀ(kA)=1 para A dada. ¿Hay más de un valor?',{'A':A},cs,steps=[p('Escribimos las tres componentes del vector escalado','Multiplicar A por k da (−2k,k,−k)ᵀ. Su producto consigo mismo es la suma de los cuadrados de sus componentes.',math=[r'(-2k)^2+k^2+(-k)^2=1']),p('Reducimos a una ecuación en k','Al cuadrar, los signos negativos desaparecen. Reunimos los tres términos con k² y dividimos entre 6.',math=[r'4k^2+k^2+k^2=1',r'6k^2=1\quad\Longrightarrow\quad k^2=\frac16']),p('No perdemos la raíz negativa','Una ecuación k²=a con a>0 tiene dos soluciones reales. Los dos signos producen longitud 1; el negativo invierte el sentido del vector.',math=[r'k=\pm\frac1{\sqrt6}=\pm\frac{\sqrt6}{6}'])],answer='Hay dos valores: k=√6/6 y k=−√6/6.',graph={'kind':'vector3','initial':[-2,1,-1]}))
 A=M([[-3,2,1],[4,5,0]])
 L.append(lesson(17,'Matriz de productos entre columnas','Sean aⱼ=colⱼ(A), j=1,2,3. Verifique que la entrada (i,j) de AᵀA es aᵢ·aⱼ=aᵢᵀaⱼ.',{'A':A},[closed_case('AᵀA',mul(T(N('A',A)),N('A',A)))],steps=[p('Por qué aparecen las columnas','La fila i de Aᵀ es exactamente la columna i de A escrita horizontalmente. Multiplicarla por la columna j de A produce el producto escalar entre ambas columnas.',math=[r'(A^TA)_{ij}=\sum_{k=1}^{2}a_{ki}a_{kj}=\mathbf{a}_i^T\mathbf{a}_j'])],answer='AᵀA='+str((A.T*A).tolist())+'.'))
 L.append(markov(18,M([[R(1,3),R(2,5)],[R(2,3),R(3,5)]]),M([[R(2,3)],[R(1,3)]]),['R','S'],'Con la matriz A y distribución inicial dadas, determine (a) la distribución después de un año y (b) la distribución estable.',1))
 L.append(markov(19,M([[R(1,3),R(1,2)],[R(2,3),R(1,2)]]),M([[R(1,3)],[R(2,3)]]),['M','N'],'Cada año M conserva 1/3 de sus clientes y 2/3 cambian a N; N conserva 1/2 y 1/2 cambian a M. Con x₀=(1/3,2/3)ᵀ, determine (a) la distribución después de un año y (b) la estable.',1))
 L.append(markov(20,M([[R(1,3),R(1,2),R(1,4)],[R(2,3),R(1,4),R(1,2)],[0,R(1,4),R(1,4)]]),M([[R(1,3)]]*3),['R','S','T'],'Con la matriz de retención y cambio de clientes dada y x₀=(1/3,1/3,1/3)ᵀ: (a) calcule uno y dos años; (b) demuestre que x*=(21/53,24/53,8/53)ᵀ es estable; (c) determine qué compañía tendrá la participación mayor a largo plazo y su porcentaje.',2,M([[R(21,53)],[R(24,53)],[R(8,53)]])))
 L.append(markov(21,M([['0.4',0,'0.4'],[0,'0.5','0.4'],['0.6','0.5','0.2']]),M([[R(1,3)]]*3),['R','S','T'],'Repita los tres incisos del ejercicio 20 con la nueva matriz A. En (b), compruebe x*=(10/37,12/37,15/37)ᵀ.',2,M([[R(10,37)],[R(12,37)],[R(15,37)]])))
 for id,A in [(22,M([[1,1],[1,1]])),(23,M([[1,1],[0,1]]))]:
  L.append(lesson(id,'Cuadrado de una matriz binaria','Trabajando en F₂, demuestre que A²='+('O.' if id==22 else 'I₂.'),{'A':A},[closed_case('A² módulo 2',power(N('A',A),2),True)],steps=[p('La suma binaria es distinta de la suma real','Los productos de bits se calculan normalmente. Después de sumar los productos de una casilla guardamos su resto módulo 2. Así 1+1 tiene suma usual 2, pero resultado binario 0.',math=[r'0+0=0,\quad0+1=1,\quad1+0=1,\quad1+1=0\quad(\bmod 2)'])],answer='A²='+('O₂×₂.' if id==22 else 'I₂.'),domain='F2'))
 for id,A in [(24,M([[0,1],[0,1]])),(25,M([[0,0],[1,1]]))]:
  a=N('A',A);cs=[closed_case('(a) A²−A' if id==24 else '(a) A²+A',sub(power(a,2),a) if id==24 else add(power(a,2),a),True),closed_case('(b) A³+A²+A' if id==24 else '(b) A⁴+A³+A²',add(add(power(a,3),power(a,2)),a) if id==24 else add(add(power(a,4),power(a,3)),power(a,2)),True)]
  L.append(lesson(id,'Polinomio de una matriz binaria','Determine los incisos (a) y (b) indicados usando aritmética módulo 2.',{'A':A},cs,steps=[p('Primero las potencias; después las sumas','Cada potencia se obtiene por multiplicación matricial. Cada suma o diferencia se reduce módulo 2. En F₂, restar una matriz coincide con sumarla porque cada bit es su propio opuesto.')],answer='(a) O₂×₂; (b) A.',domain='F2'))
 assert len(L)==25
 return L
