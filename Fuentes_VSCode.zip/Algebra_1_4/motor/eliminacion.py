"""Eliminación explicada operación por operación, con fracciones exactas.
Los mismos pasos alimentan la web y el PDF. No se salta de una orden de fila
al resultado: se muestran los múltiplos, cada columna, el sistema nuevo,
la sustitución, el despeje y cada comprobación.
"""
import sympy as S

def f(x):return S.latex(S.sympify(x))

def suma_terminos(terms):
    out=''
    for coef,term in terms:
        coef=S.sympify(coef)
        if coef==0:continue
        negative=bool(coef.is_negative)
        mag=-coef if negative else coef
        part=('' if mag==1 and term else (r'\left('+f(mag)+r'\right)' if mag.free_symbols and not term and mag.is_Add else f(mag)))+term
        out+=((' - ' if out else '-') if negative else (' + ' if out else ''))+part
    return out or '0'

def lhs(row,vs):return suma_terminos([(a,v) for a,v in zip(row[:-1],vs)])
def eq(row,vs):return lhs(row,vs)+' = '+f(row[-1])
def step(t,b,maths=None,matrix=None,system=None,**extra):
    d={'titulo':t,'texto':b,**extra}
    if maths:d['formulas']=maths if isinstance(maths,list) else [maths]
    if matrix is not None:d['matriz']=[[str(v) for v in r] for r in matrix]
    if system is not None:d['sistema']=system
    return d

def elim(rows,vs):
    rows=[[S.Rational(x) for x in row] for row in rows];M=[row[:] for row in rows]
    n=len(vs);symbols=S.symbols(' '.join(vs),seq=True);steps=[]
    def action(text,formula):return {'explica':text,'formula':formula}
    def add(title,text,**kw):steps.append(step(title,text,**kw))
    def term(a,var):return suma_terminos([(a,var)])
    def audit():return [[str(x) for x in row] for row in M]
    add('Primero: ¿qué significa resolver este sistema?',
        'Las letras '+', '.join(vs)+' representan números que todavía no conocemos. Una solución es una elección de esos números que hace verdaderas TODAS las ecuaciones al mismo tiempo. La llave de la izquierda significa que las condiciones se deben cumplir juntas.',
        objetivo='Encontrar '+('una misma pareja de valores.' if n==2 else 'un mismo grupo de valores para las '+str(n)+' letras.'),
        acciones=[action('El número 3 delante de '+vs[0]+' indica tres veces ese mismo valor; es decir, sumar tres copias:', '3'+vs[0]+'='+vs[0]+'+'+vs[0]+'+'+vs[0]),
                  action('Ejemplo numérico de la notación: si '+vs[0]+' valiera 2, tres veces ese valor sería 6. Este 2 es solo un ejemplo; todavía no es la respuesta del ejercicio. El punto centrado indica multiplicación:',r'3\cdot 2=2+2+2=6')],
        pregunta='¿Basta con que los valores funcionen en una sola ecuación?',respuesta='No. Deben funcionar en todas las ecuaciones del sistema, usando los mismos valores.')
    add('Nuestro plan: ir quitando letras',
        'Una ecuación con una sola letra es más fácil de resolver. Vamos a combinar ecuaciones para que una letra desaparezca. Cuando sepamos un valor, lo pondremos en las ecuaciones que faltan.',
        objetivo=('Primero quitar '+vs[0]+' para calcular '+vs[1]+'. Después calcular '+vs[0]+'.') if n==2 else 'Primero quitar '+vs[0]+' de las otras ecuaciones. Después seguir con las letras restantes.',
        porque='Si una cantidad se resta de sí misma, queda cero. Usaremos esta idea con términos que tengan la misma letra.',acciones=[action('Ejemplo de la idea que utilizaremos:',r'3x-3x=0')],
        conclusion='Eliminar una letra de una ecuación NO significa que su valor sea cero; significa que sus términos se cancelaron en esa cuenta.')
    piv=[];r=0
    for c in range(n):
        avail=[i for i in range(r,len(M)) if M[i][c]]
        if not avail:continue
        k=min(avail,key=lambda i:abs(M[i][c]))
        if k!=r:
            M[r],M[k]=M[k],M[r]
            add('Ponemos una ecuación más cómoda arriba','Cambiamos de lugar las ecuaciones '+str(r+1)+' y '+str(k+1)+'. Las condiciones siguen siendo las mismas; solamente cambia el orden en que las leemos.',
                porque='La ecuación que subimos tiene un número más pequeño delante de '+vs[c]+'. Eso facilita las multiplicaciones que haremos a continuación.',system=[eq(row,vs) for row in M],matriz_resultante=audit())
        piv.append((r,c))
        for i in range(r+1,len(M)):
            a,p=M[i][c],M[r][c]
            if not a:continue
            g=S.gcd(abs(a),abs(p));u=abs(p)/g;v=abs(a)/g
            subtract=bool(a*p>0);sign=-1 if subtract else 1
            common=abs(u*a);old=M[i][:];top=M[r][:]
            top_scaled=[v*x for x in top];old_scaled=[u*x for x in old]
            new=[u*x+sign*v*y for x,y in zip(old,top)]
            add('¿Cómo haremos desaparecer '+vs[c]+'?',
                'Trabajaremos con las ecuaciones '+str(r+1)+' y '+str(i+1)+'. Queremos que los términos con '+vs[c]+' tengan el mismo tamaño. Así podremos '+('restarlos.' if subtract else 'sumarlos, porque tienen signos opuestos.'),
                objetivo='Conseguir términos con '+str(common)+' veces '+vs[c]+' en las dos ecuaciones.',
                tabla={'cabeceras':['Dónde miramos','Qué término hay','Qué necesitamos hacer'], 'filas':[
                    ['Ecuación '+str(r+1),'$'+term(p,vs[c])+'$', ('La dejamos igual.' if v==1 else 'Multiplicar TODA esta ecuación por '+str(v))],
                    ['Ecuación '+str(i+1),'$'+term(a,vs[c])+'$', ('La dejamos igual.' if u==1 else 'Multiplicar TODA esta ecuación por '+str(u))]]},
                porque=('Tener '+str(common)+' veces la misma letra en ambos lados de la resta nos permitirá cancelarla.' if subtract else 'Al sumar la misma cantidad con signos opuestos obtenemos cero.'),
                conclusion='Estos multiplicadores se eligen para igualar los términos con '+vs[c]+'. Los demás términos también se multiplican para conservar la igualdad.')
            for number,row,mult,scaled in [(r+1,top,v,top_scaled),(i+1,old,u,old_scaled)]:
                if mult==1:continue
                lines=[]
                for j,var in enumerate(vs):
                    if row[j]!=0:lines.append(['Término con '+var,'$'+term(row[j],var)+'$','$'+f(mult)+r'\cdot\left('+term(row[j],var)+r'\right)='+term(scaled[j],var)+'$'])
                lines.append(['Número a la derecha del igual','$'+f(row[-1])+'$','$'+f(mult)+r'\cdot\left('+f(row[-1])+r'\right)='+f(scaled[-1])+'$'])
                add('Multiplicamos la ecuación '+str(number)+' por '+str(mult),
                    'Multiplicar una ecuación por '+str(mult)+' significa multiplicar CADA término de la izquierda y también el número de la derecha. La igualdad se conserva porque hacemos lo mismo en ambos lados.',
                    acciones_previas=[action('Esta es la ecuación antes de multiplicar:',eq(row,vs))],
                    acciones=[action('Después de hacer todas las multiplicaciones queda:',eq(scaled,vs))],
                    tabla={'cabeceras':['Parte de la ecuación','Antes','La cuenta y su resultado'],'filas':lines},
                    conclusion='La misma condición ahora está escrita con los términos multiplicados. Ya tenemos el tamaño que buscábamos para '+vs[c]+'.',
                    pregunta='¿Podríamos multiplicar solamente el término con '+vs[c]+'?',respuesta='No. Eso cambiaría la condición. Debemos multiplicar todos los términos, también el número que está después del igual.')
            lines=[]
            for j,var in enumerate(vs):
                if old_scaled[j] or top_scaled[j]:
                    expr=term(old_scaled[j],var)+(' - ' if subtract else ' + ')+r'\left('+term(top_scaled[j],var)+r'\right)='+term(new[j],var)
                    lines.append(['Los términos con '+var,'$'+expr+'$','Se cancela esta letra.' if new[j]==0 else 'Quedan '+term(new[j],var).replace('\\','')+'.'])
            rhs=f(old_scaled[-1])+(' - ' if subtract else ' + ')+r'\left('+f(top_scaled[-1])+r'\right)'
            if subtract and top_scaled[-1]<0:rhs+='='+f(old_scaled[-1])+'+'+f(-top_scaled[-1])
            rhs+='='+f(new[-1]);lines.append(['Los números a la derecha del igual','$'+rhs+'$','Este será el número de la nueva igualdad.'])
            add(('Restamos' if subtract else 'Sumamos')+' las dos ecuaciones preparadas',
                ('Restamos la ecuación '+str(r+1)+' preparada a la ecuación '+str(i+1)+' preparada.' if subtract else 'Sumamos las dos ecuaciones preparadas.')+' Juntamos cada término solo con otro que tenga la misma letra. Los números sin letra se calculan por separado.',
                acciones=[action('Primera igualdad que usaremos:',eq(old_scaled,vs)),action(('Le restamos esta igualdad:' if subtract else 'Le sumamos esta igualdad:'),eq(top_scaled,vs))],
                tabla={'cabeceras':['Qué agrupamos','Cuenta','Qué significa'],'filas':lines},
                conclusion='Los términos con '+vs[c]+' dan cero. '+('Recuerda: restar un número negativo equivale a sumar su opuesto.' if subtract and top_scaled[-1]<0 else 'Los términos con letras distintas no se mezclan.'))
            M[i]=new
            remaining=[vs[j] for j in range(n) if new[j]]
            add('Mira lo que hemos conseguido',
                'La nueva ecuación es el resultado de la cuenta anterior. '+('Todavía contiene '+', '.join(remaining)+'. Seguiremos reduciendo las condiciones.' if len(remaining)>1 else ('Solo contiene '+remaining[0]+': después podremos despejarla.' if remaining else 'Ya no contiene letras. Tenemos que decidir si la igualdad numérica es verdadera o imposible.')),
                acciones=[action('Escribimos la nueva condición:',eq(new,vs))],
                conclusion='Conservamos la ecuación '+str(r+1)+' y reemplazamos la '+str(i+1)+' por esta nueva condición. De esa manera conservamos toda la información necesaria para resolver el sistema.',
                system=[eq(row,vs) for row in M],matriz_resultante=audit())
            nonzero=[abs(x) for x in new if x];h=S.gcd_list(nonzero) if nonzero else 1
            if h not in (0,1) and sum(x!=0 for x in new[:-1])>1:
                M[i]=[x/h for x in new]
                add('Escribimos la misma condición con números más pequeños',
                    'Todos los números de esta ecuación se pueden dividir entre '+str(h)+' sin dejar restos. Dividimos ambos lados entre ese mismo número. Así la condición no cambia y las siguientes cuentas serán más sencillas.',
                    acciones=[action('Antes de simplificar:',eq(new,vs)),action('Después de dividir todos los términos entre '+str(h)+':',eq(M[i],vs))],matriz_resultante=audit())
        r+=1
        if r==len(M):break
    A=S.Matrix([row[:-1] for row in rows]);b=S.Matrix([row[-1] for row in rows]);bad=[row for row in M if all(x==0 for x in row[:-1]) and row[-1]!=0]
    native=[[int(x) if x.q==1 else str(x) for x in row] for row in rows]
    if bad:
        add('Esta igualdad nos dice que no hay solución',
            'Al hacer las cuentas, todas las letras desaparecieron y quedó la igualdad que ves abajo. Cero no puede ser igual a '+str(bad[0][-1])+'. Como esa condición tendría que cumplirse junto con las demás, ningún grupo de valores puede resolver el sistema.',
            acciones=[action('Esta es la contradicción encontrada:',eq(bad[0],vs))],conclusion='El resultado es «sin solución». No significa que debamos responder con ceros: significa que no existe una respuesta que cumpla todas las condiciones.',
            pregunta='¿Responder '+', '.join(v+' = 0' for v in vs)+' resolvería esta contradicción?',respuesta='No. La contradicción ya no depende de las letras. Ningún valor puede convertir cero en otro número.')
        return steps,'Sin solución.',{'tipo':'ninguna','matriz':native,'variables':vs}
    sol=list(S.linsolve((A,b),symbols))[0];free=sorted(set().union(*(x.free_symbols for x in sol)),key=str)
    parameters={q:S.Symbol('t' if len(free)==1 else 't_'+str(i+1)) for i,q in enumerate(free)};known=dict(parameters)
    if free:
        add('Una letra puede elegirse libremente',
            'Las condiciones que quedan no fijan un único valor para '+', '.join(str(q) for q in free)+'. Podemos elegir ese valor y calcular los demás. Para representar todas las elecciones usamos otra letra, llamada parámetro.',
            acciones=[action('La letra '+str(q)+' será el número que elijamos. Lo llamaremos '+str(parameters[q])+':',f(q)+'='+f(parameters[q])) for q in free],
            conclusion='Un parámetro no es una respuesta que falte: es una forma de describir muchas respuestas a la vez. Primero lo dejamos libre; en un problema real también revisaremos si hay límites como cantidades no negativas.')
    for ri,ci in reversed(piv):
        row=M[ri];var=vs[ci];coef=row[ci];others=[j for j in range(ci+1,n) if row[j]]
        if others:
            replacements='; '.join(vs[j]+' = '+str(known[symbols[j]]) for j in others)
            substituted=suma_terminos([(coef,var)]+[(row[j],r'\left('+f(known[symbols[j]])+r'\right)') for j in others])+'='+f(row[-1])
            products=[S.expand(row[j]*known[symbols[j]]) for j in others];total=S.expand(sum(products));right=S.expand(row[-1]-total)
            add('Usamos lo que ya sabemos para hallar '+var,
                'Ya sabemos '+replacements+'. Sustituir significa escribir ese valor cada vez que aparezca su letra. Usamos paréntesis para que se vea qué número estamos multiplicando.',
                objetivo='Dejar solamente '+var+' como letra desconocida en esta ecuación.',
                acciones=[action('Tomamos esta condición que obtuvimos antes:',eq(row,vs)),action('Reemplazamos las letras conocidas por sus valores:',substituted)])
            productrows=[]
            for j,q in zip(others,products):
                productrows.append(['El término '+term(row[j],vs[j]),'$'+f(row[j])+r'\cdot\left('+f(known[symbols[j]])+r'\right)$','$'+f(q)+'$'])
            add('Calculamos las multiplicaciones que ya se pueden hacer',
                'La letra '+var+' sigue sin conocerse. Las otras partes ya tienen un valor o una expresión conocida y podemos efectuar sus productos.',
                tabla={'cabeceras':['Parte conocida','La multiplicación','Resultado'],'filas':productrows},
                acciones=[action('Al reunir esas partes conocidas, la ecuación queda:',suma_terminos([(coef,var),(total,'')])+'='+f(row[-1]))])
            if total!=0:
                numeric=not total.free_symbols
                remove=-total
                verb=('restamos '+str(total) if total.is_positive else 'sumamos '+str(-total)) if numeric else 'quitamos la expresión '+str(total)
                if numeric:
                    balanced=suma_terminos([(coef,var),(total,''),(remove,'')])+'='+suma_terminos([(row[-1],''),(remove,'')])
                else:balanced=suma_terminos([(coef,var)])+'='+f(row[-1])+r'-\left('+f(total)+r'\right)'
                add('Dejamos el término con '+var+' solo a un lado',
                    'Para quitar la parte conocida, '+verb+' en AMBOS lados. Piensa en una balanza: si hacemos lo mismo a ambos lados, la igualdad se mantiene.',
                    acciones=[action('Hacemos la misma operación a la izquierda y a la derecha:',balanced),action('Las partes que se compensan dan cero; queda:',suma_terminos([(coef,var)])+'='+f(right))],
                    conclusion='«Pasar al otro lado» es una forma abreviada de decir que hicimos la misma suma o resta en los dos lados.')
        else:
            right=row[-1]
            add('Ya tenemos una ecuación con una sola letra',
                'En esta condición solamente falta conocer '+var+'. El número '+str(coef)+' está multiplicando a esa letra. Ahora podemos deshacer esa multiplicación.',
                acciones=[action('Esta es la condición que vamos a resolver:',eq(row,vs))])
        value=S.simplify(right/coef);known[symbols[ci]]=value
        if coef!=1:
            add('Calculamos cuánto vale '+var,
                'Para deshacer una multiplicación por '+str(coef)+', dividimos AMBOS lados entre '+str(coef)+'. En el lado izquierdo queda una sola '+var+'. En el derecho hacemos la división.',
                acciones=[action('Dividimos los dos lados entre el mismo número:',r'\frac{'+term(coef,var)+'}{'+f(coef)+r'}=\frac{'+f(right)+'}{'+f(coef)+'}'),action('Ya podemos leer el valor de la letra:',var+r'=\frac{'+f(right)+'}{'+f(coef)+'}='+f(value))],
                conclusion=('Un número negativo dividido entre otro negativo da positivo.' if coef<0 and right.is_negative else 'Este valor se usará en las ecuaciones donde todavía falten letras.'))
        else:
            add('Leemos el valor de '+var,'La letra ya está sola: su número multiplicador es 1, que no se escribe. La igualdad nos dice directamente cuánto vale.',acciones=[action('Anotamos el valor encontrado:',var+'='+f(value))])
    final=[S.simplify(x.subs(parameters)) for x in sol]
    add('Reunimos la respuesta; todavía falta comprobarla',
        'Escribimos todos los valores en el orden '+', '.join(vs)+'. '+('Dependen del número que elijamos para el parámetro, por eso describen una familia de respuestas.' if free else 'Estos valores deben funcionar juntos, no cada uno en una ecuación diferente.'),
        system=[v+'='+f(x) for v,x in zip(vs,final)],conclusion='El siguiente paso es volver a las ecuaciones del enunciado y comprobar cada condición.')
    if free:
        ts=list(parameters.values());t=ts[0]
        trials=[]
        for trial in (0,1):
            sub={q:(trial if q==t else 0) for q in ts};trials.append([str(trial)]+[str(S.simplify(q.subs(sub))) for q in final])
        add('Dos elecciones distintas producen dos soluciones',
            'Esta tabla muestra qué pasa al elegir 0 o 1 para el parámetro. Sustituimos la elección en las expresiones de la respuesta. Cada fila es un grupo completo de valores.',
            tabla={'cabeceras':['Elección de '+str(t)]+vs,'filas':trials},
            conclusion='No hay una sola solución. Hay una para cada elección permitida del parámetro. El deslizador de la web permite comprobar más ejemplos.')
    for i,row in enumerate(rows):
        substituted=suma_terminos([(a,r'\left('+f(x)+r'\right)') for a,x in zip(row[:-1],final)])+'='+f(row[-1]);products=[S.expand(a*x) for a,x in zip(row[:-1],final)];total=S.simplify(sum(products))
        acts=[action('La condición del enunciado era:',eq(row,vs)),action('Ponemos nuestros valores donde estaban las letras:',substituted),action('Hacemos las multiplicaciones y luego la suma:',suma_terminos([(q,'') for q in products])+'='+f(row[-1])),action('Comparamos los dos lados:',f(total)+'='+f(row[-1]))]
        add('¿La respuesta cumple la ecuación '+str(i+1)+'?',
            'Comprobar significa volver a la condición original y calcularla con nuestra respuesta. Si los dos lados dan el mismo número, esta condición sí se cumple. Deben cumplirse todas.',
            acciones=acts,conclusion='La igualdad final es verdadera. '+('Al simplificar, los términos del parámetro se compensan: la condición vale para cualquier elección permitida.' if free else 'Nuestra respuesta sí cumple la ecuación '+str(i+1)+'.'))
    plain='; '.join(v+' = '+str(x) for v,x in zip(vs,final))+('. Parámetro real.' if free else '.')
    return steps,plain,{'tipo':'infinita' if free else 'unica','matriz':native,'variables':vs,'solucion':[str(x) for x in final]}

def sistema_lineal(numero,matriz,variables=None,titulo='Sistema lineal por eliminación',enunciado='Resuelva el sistema por el método de eliminación.'):
    variables=variables or ['x','y','z'][:len(matriz[0])-1]
    if len(matriz[0])-1!=len(variables):raise ValueError('El número de variables no coincide con las columnas de la matriz.')
    pasos,resultado,meta=elim(matriz,variables)
    return dict(id=str(numero),titulo=titulo,enunciado=enunciado,sistema=[eq([S.Rational(x) for x in r],variables) for r in matriz],pasos=pasos,resultado=resultado,**meta)

def paso(titulo,texto,*formulas):return dict(titulo=titulo,texto=texto,formulas=list(formulas))
