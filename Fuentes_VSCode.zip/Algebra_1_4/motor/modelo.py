"""Modelo exacto y trazable: cada casilla conserva factores, productos y acumulados."""
import sympy as S
from dataclasses import dataclass

def value(x):return S.sympify(str(x),rational=True,locals={'r':S.Symbol('r',real=True)})
def M(rows):return S.Matrix([[value(x) for x in row] for row in rows])
def rows(A):return [[str(x) for x in A.row(i)] for i in range(A.rows)]
def tex(A):
 if isinstance(A,S.MatrixBase):return r'\begin{bmatrix}'+r'\\'.join('&'.join(S.latex(x) for x in A.row(i)) for i in range(A.rows))+r'\end{bmatrix}'
 return S.latex(A)
def p(title,text,math=None,**kw):return {'title':title,'text':text,'math':math or [],**kw}
def mat(name,A):
 numeric=None if any(x.free_symbols for x in A) else [[float(S.N(A[i,j])) for j in range(A.cols)] for i in range(A.rows)]
 return {'name':name,'rows':rows(A),'tex':tex(A),'texRows':[[S.latex(A[i,j]) for j in range(A.cols)] for i in range(A.rows)],'values':numeric}
@dataclass
class E:
 op:str
 name:str=''
 data:object=None
 args:tuple=()
 k:object=None

def N(name,A):return E('data',name,A)
def add(a,b):return E('add',args=(a,b))
def sub(a,b):return E('sub',args=(a,b))
def mul(a,b):return E('mul',args=(a,b))
def scale(k,a):return E('scale',args=(a,),k=value(k))
def T(a):return E('transpose',args=(a,))
def power(a,k):
 if k<0:raise ValueError('Solo se implementan potencias no negativas.')
 return E('power',args=(a,),k=k)
def label(e):
 if e.op=='data':return e.name
 if e.op=='scale':return str(e.k)+'('+label(e.args[0])+')'
 if e.op=='transpose':return '('+label(e.args[0])+')ᵀ'
 if e.op=='power':return '('+label(e.args[0])+')^'+str(e.k)
 return '('+label(e.args[0])+{'add':' + ','sub':' − ','mul':' · '}[e.op]+label(e.args[1])+')'
class Compiler:
 def __init__(self,binary=False):self.nodes=[];self.binary=binary
 def norm(self,A):return A.applyfunc(lambda x:S.Mod(x,2)) if self.binary else A.applyfunc(S.simplify)
 def run(self,e):
  if e.op=='data':return e.data,e.name
  if e.op=='power':
   A,name=self.run(e.args[0]);k=int(e.k)
   if A.rows!=A.cols:raise ValueError('Las potencias requieren una matriz cuadrada: '+name+' tiene tamaño '+str(A.rows)+' × '+str(A.cols)+'.')
   if k==0:return self.record('copy',name+'^0',[S.eye(A.rows)],['I'+str(A.rows)],S.eye(A.rows))
   if k==1:return self.record('copy',name+'^1',[A],[name],A)
   R=A
   for j in range(2,k+1):R,_=self.record('mul',name+'^'+str(j),[R,A],[name if j==2 else name+'^'+str(j-1),name],self.norm(R*A))
   return R,name+'^'+str(k)
  values=[self.run(x) for x in e.args];args=[v[0] for v in values];names=[v[1] for v in values];op=e.op
  if op in ('add','sub') and args[0].shape!=args[1].shape:raise ValueError(f'No se pueden sumar o restar tamaños {args[0].rows} × {args[0].cols} y {args[1].rows} × {args[1].cols}. Cada posición debe tener una pareja en la otra matriz.')
  if op=='mul' and args[0].cols!=args[1].rows:raise ValueError(f'Producto no definido: {args[0].rows} × {args[0].cols} por {args[1].rows} × {args[1].cols}. Las dimensiones interiores {args[0].cols} y {args[1].rows} no coinciden.')
  R=args[0]+args[1] if op=='add' else args[0]-args[1] if op=='sub' else args[0]*args[1] if op=='mul' else e.k*args[0] if op=='scale' else args[0].T
  return self.record(op,label(e),args,names,self.norm(R),e.k)
 def record(self,op,name,args,names,R,k=None):
  cells=[]
  for i in range(R.rows):
   for j in range(R.cols):
    acts=[];pairs=[];raw=None
    if op=='mul':
     acc=S.Integer(0)
     for t in range(args[0].cols):
      a,b=args[0][i,t],args[1][t,j];v=S.simplify(a*b);new=S.simplify(acc+v)
      pairs.append({'a':str(a),'b':str(b),'product':str(v),'before':str(acc),'after':str(new),'aTex':tex(a),'bTex':tex(b),'productTex':tex(v),'beforeTex':tex(acc),'afterTex':tex(new),'k':t})
      rule='Dos signos negativos producen un signo positivo.' if a.is_negative and b.is_negative else 'Un factor cero hace que este producto sea cero.' if a==0 or b==0 else 'Multiplicamos los dos valores de esta pareja, conservando sus signos.'
      acts += [{'text':f'Pareja {t+1}: entrada ({i+1}, {t+1}) del primer factor y ({t+1}, {j+1}) del segundo. '+rule,'math':r'('+tex(a)+r')('+tex(b)+')='+tex(v)}, {'text':f'La suma llevaba {acc}. Añadimos el producto {v}. '+('Ya usamos todas las parejas.' if t==args[0].cols-1 else 'Todavía faltan parejas; no guardamos la casilla.'),'math':r'('+tex(acc)+')+('+tex(v)+')='+tex(new)}]
      acc=new
     raw=acc;select=f'La fila {i+1} del primer factor se lee de izquierda a derecha; la columna {j+1} del segundo, de arriba abajo. Emparejamos sus números en el mismo orden.'
    else:
     a=args[0][j,i] if op=='transpose' else args[0][i,j]
     if op=='transpose':raw=a;formula=rf'c_{{{i+1}{j+1}}}=a_{{{j+1}{i+1}}}='+tex(a);select=f'Para la posición ({i+1}, {j+1}) del resultado, buscamos la posición ({j+1}, {i+1}) de origen. Transponer intercambia fila y columna; el número se conserva.'
     elif op=='copy':raw=a;formula=rf'c_{{{i+1}{j+1}}}='+tex(a);select='Leemos la entrada de la matriz indicada. Una potencia cero es la identidad del mismo orden.' if '^0' in name else 'La primera potencia conserva la matriz original; todavía no multiplicamos dos copias.'
     elif op=='scale':raw=S.simplify(k*a);formula=r'('+tex(k)+')('+tex(a)+')='+tex(raw);select=f'Multiplicar por {k} afecta a todas las entradas. En esta acción trabajamos solo con la casilla ({i+1}, {j+1}).'
     else:
      b=args[1][i,j];raw=S.simplify(a+b if op=='add' else a-b);formula=r'('+tex(a)+(')+(' if op=='add' else ')-(')+tex(b)+')='+tex(raw);select=f'Buscamos la misma posición ({i+1}, {j+1}) en ambas matrices. Los paréntesis conservan los signos de los valores.'
     acts.append({'text':select,'math':formula})
    if self.binary:
     answer=R[i,j];acts.append({'text':f'La suma o cuenta usual dio {raw}. En F₂ guardamos el resto al dividir entre 2: {answer}. Un total par da 0 y uno impar da 1.','math':tex(raw)+r'\equiv '+tex(answer)+r'\pmod 2'})
    cells.append({'i':i,'j':j,'pairs':pairs,'select':select,'actions':acts,'raw':str(raw),'value':str(R[i,j]),'valueTex':tex(R[i,j]),'rawTex':tex(raw),'origin':[j,i] if op=='transpose' else [i,j]})
  node={'id':len(self.nodes),'op':op,'name':name,'inputs':[mat(n,A) for n,A in zip(names,args)],'result':mat(name,R),'cells':cells,'binary':self.binary,'k':str(k) if k is not None else None};self.nodes.append(node)
  return R,name

def make_case(name,expr,binary=False,goal='',plot=None):
 c=Compiler(binary);case={'name':name,'nodes':c.nodes,'goal':goal,'binary':binary}
 try:
  R,_=c.run(expr);case['result']=mat(name,R)
 except ValueError as e:case['error']=str(e);c.nodes.clear()
 if plot:case['plot']=plot
 return case

def case_steps(case,case_index):
 out=[p(case['name']+' · entendemos la tarea',case.get('goal') or 'Vamos a construir el resultado respetando los paréntesis y mostrando el origen de cada número.',case=case_index)]
 if case.get('error'):return out+[p('La operación no está definida',case['error'],conclusion='No es una matriz cero: esta expresión no tiene resultado con estos tamaños.',case=case_index)]
 for node in case['nodes']:
  op=node['op'];kind={'mul':'Multiplicación: una fila con una columna','add':'Suma: combinar posiciones iguales','sub':'Resta: conservar los signos','scale':'Producto por un número','transpose':'Transposición: cambiar posiciones','copy':'Definición de la potencia'}[op]
  dims='; '.join(x['name']+': '+str(len(x['rows']))+' filas y '+str(len(x['rows'][0]))+' columnas' for x in node['inputs'])
  out.append(p(kind+' · '+node['name'],'Leemos los operandos antes de calcular. '+dims+'. '+('Coinciden las dimensiones interiores. El resultado tendrá tantas filas como el primer factor y tantas columnas como el segundo.' if op=='mul' else 'Usamos las posiciones indicadas por la operación; no mezclamos casillas de otras filas ni columnas.'),matrices=node['inputs'],labNode=node['id'],case=case_index))
  for q in node['cells']:
   out.append(p(node['name']+f' · fila {q["i"]+1}, columna {q["j"]+1}',q['select'],actions=q['actions'],conclusion=f'Guardamos {q["value"]} únicamente en la posición ({q["i"]+1}, {q["j"]+1}).',labNode=node['id'],labCell=[q['i'],q['j']],case=case_index))
  out.append(p('Reunimos '+node['name'],'Cada cuenta se coloca en la posición que acabamos de calcular. Comprueba la cantidad de filas y columnas antes de seguir con otra operación.',matrices=[node['result']],labNode=node['id'],case=case_index))
 return out

GLOSSARY=[['Entrada (i,j)','Número o expresión de la fila i y columna j; ambas se cuentan desde 1.'],['Igualdad de matrices','Mismo tamaño e igualdad en todas las posiciones correspondientes.'],['Producto matricial','Cada entrada se calcula con una fila del primer factor y una columna del segundo.'],['Potencia Aᵏ','Producto de k copias de A; A⁰ es la identidad, no una matriz de ceros.'],['Transpuesta','Intercambia filas con columnas: la posición (i,j) pasa a (j,i).'],['Matriz cero O','Todas sus entradas son cero; su tamaño depende del contexto.'],['Identidad Iₙ','Matriz cuadrada con unos en la diagonal y ceros fuera de ella.'],['Módulo 2','Solo se conserva el resto 0 o 1 al dividir una cuenta entera entre 2.']]

def lesson(id,title,statement,matrices=None,cases=None,steps=None,answer='',group='practicos',objective='',note='',domain='R',graph=None):
 cases=cases or [];body=list(steps or [])
 for k,c in enumerate(cases):body+=case_steps(c,k)
 return {'id':str(id),'key':'1.4-'+str(id),'title':title,'statement':statement,'group':group,'domain':domain,'matrices':[mat(n,A) for n,A in (matrices or {}).items()],'cases':cases,'steps':body,'answer':answer,'objective':objective or ('Justificar la afirmación para todos los objetos permitidos, no solo para un ejemplo.' if group=='teoricos' else 'Comprender la tarea y resolver todos sus incisos con cuentas verificables.'),'note':note,'glossary':GLOSSARY,'graph':graph}
