"""Argumentos originales: hipótesis explícitas, pasos justificados y cierre formal."""
from .modelo import *
from .practicos import eq_cases,closed_case

def step(t,s,*math,**kw):
 explicit=kw.pop('math',[])
 return p(t,s,list(math)+list(explicit),**kw)
def proof(n,title,statement,hyp,thesis,idea,steps,answer,cases=None,note='',domain='R',graph=None):
 d=lesson('T.'+str(n),title,statement,cases=[],steps=steps,answer=answer,group='teoricos',objective=thesis,note=note,domain=domain,graph=graph)
 d['proof']={'hypotheses':hyp,'thesis':thesis,'idea':idea,'type':'Demostración formal' if n not in (8,9,25,33,34,35,36,39,40) else 'Clasificación con justificación formal'}
 d['cases']=cases or []
 # Los ejemplos se etiquetan y quedan separados de la demostración general.
 d['examples']=[]
 for k,c in enumerate(d['cases']):
  if not c.get('exploration'):d['examples']+=case_steps(c,k)
 return d

def build():
 L=[];A0=M([[1,2],[-1,3]]);B0=M([[2,-1],[4,0]]);C0=M([[0,3],[2,-2]]);a,b,c=N('A',A0),N('B',B0),N('C',C0);I=N('I₂',S.eye(2))
 L.append(proof(1,'Asociatividad y unicidad del opuesto','Demuestre los incisos (b) y (d) del teorema 1.1.','A, B y C son matrices reales m×n; m,n son positivos.','Probar A+(B+C)=(A+B)+C y que A tiene un único inverso aditivo.','Para probar igualdad de matrices basta comparar cada posición. Para unicidad debemos probar que cualquier supuesto opuesto está obligado a ser el mismo.',[
 step('(b) Fijamos una posición arbitraria','Elegimos cualquier fila i y cualquier columna j. No las fijamos en 1: el argumento debe servir en todas las posiciones.',r'1\leq i\leq m,\qquad1\leq j\leq n'),
 step('(b) Aplicamos la definición de suma dos veces','La entrada de una suma se obtiene sumando las dos entradas de la misma posición. La asociatividad de los números reales permite cambiar la agrupación.',r'[A+(B+C)]_{ij}=a_{ij}+(b_{ij}+c_{ij})',r'=(a_{ij}+b_{ij})+c_{ij}=[(A+B)+C]_{ij}'),
 step('(b) Cerramos el primer inciso','Ambos lados tienen tamaño m×n y coinciden en cada posición arbitraria. Por definición de igualdad de matrices, son iguales.'),
 step('(d) Construimos un candidato al opuesto','Definimos D poniendo −aᵢⱼ en cada casilla. Es una matriz del mismo tamaño y su suma con A tiene todas las entradas cero.',r'd_{ij}=-a_{ij}',r'(A+D)_{ij}=a_{ij}+(-a_{ij})=0'),
 step('(d) Demostramos que no puede existir otro','Sea E cualquier matriz que cumpla A+E=O. En cada posición se cumple aᵢⱼ+eᵢⱼ=0. Restamos aᵢⱼ en esa igualdad real.',r'a_{ij}+e_{ij}=0\Longrightarrow e_{ij}=-a_{ij}=d_{ij}'),
 step('Conclusión formal','La matriz D construida existe y cualquier otro opuesto coincide con ella en todas las entradas. Por tanto es único y se denota −A. Quedan probados ambos incisos.')],
 'A+(B+C)=(A+B)+C; el único opuesto es −A.',eq_cases('Asociatividad numérica',add(a,add(b,c)),add(add(a,b),c))+[closed_case('Opuesto y suma cero',add(a,scale(-1,a)))]))
 A=M([[1,0,2],[-1,3,1]]);B=M([[1,2,0,-1],[0,1,2,3],[2,-1,1,0]]);C=M([[1,0,2],[2,1,-1],[0,3,1],[-1,2,0]])
 L.append(proof(2,'La asociatividad mediante una suma doble','Para A de 2×3, B de 3×4 y C de 4×3, demuestre A(BC)=(AB)C.','Las entradas de A, B y C son reales y sus tamaños son los indicados.','Probar que coinciden todas las entradas de los dos productos 2×3.','Expandir la entrada (i,j) de cada lado produce los mismos doce términos, agrupados de forma diferente.',[
 step('Comprobamos los tamaños antes de probar','BC es 3×3, así que A(BC) es 2×3. AB es 2×4, por lo que (AB)C también es 2×3. Ahora sí tiene sentido compararlos.'),
 step('Elegimos una entrada cualquiera','Fijamos i entre 1 y 2 y j entre 1 y 3. La letra k recorre las tres columnas de A; la letra ℓ recorre las cuatro columnas de B.',r'[A(BC)]_{ij}=\sum_{k=1}^{3}a_{ik}(BC)_{kj}'),
 step('Desarrollamos el producto interior','La definición de BC nos permite sustituir su entrada por una suma de cuatro productos. Distribuimos el factor aᵢₖ.',r'=\sum_{k=1}^{3}a_{ik}\left(\sum_{\ell=1}^{4}b_{k\ell}c_{\ell j}\right)',r'=\sum_{k=1}^{3}\sum_{\ell=1}^{4}a_{ik}b_{k\ell}c_{\ell j}'),
 step('Cambiamos el orden de una suma finita','Hay doce pares (k,ℓ). Cada término aparece exactamente una vez. Asociatividad y conmutatividad de la suma real permiten reunirlos primero según ℓ.',r'=\sum_{\ell=1}^{4}\left(\sum_{k=1}^{3}a_{ik}b_{k\ell}\right)c_{\ell j}'),
 step('Reconocemos el otro producto','La suma interior es la entrada (i,ℓ) de AB. Al multiplicar por cℓⱼ y sumar sobre ℓ aparece exactamente la definición de (AB)C.',r'=\sum_{\ell=1}^{4}(AB)_{i\ell}c_{\ell j}=[(AB)C]_{ij}'),
 step('Conclusión formal','Los tamaños coinciden y la igualdad de entradas vale para todo i,j permitido. Así A(BC)=(AB)C. No se cambió el orden de los factores de las matrices; se reorganizaron sumas finitas de números.')],
 'A(BC)=(AB)C para todas las matrices con esas dimensiones.',eq_cases('Dos agrupaciones del mismo ejemplo',mul(N('A',A),mul(N('B',B),N('C',C))),mul(mul(N('A',A),N('B',B)),N('C',C)))) )
 L.append(proof(3,'Las dos distributividades del producto','Demuestre los incisos (b) y (c) del teorema 1.2.','Para (b), A es m×p y B,C son p×n. Para (c), A,B son m×p y C es p×n.','Probar A(B+C)=AB+AC y (A+B)C=AC+BC.','Aplicar la distributividad real dentro de la suma que define cada entrada.',[
 step('(b) Escribimos la entrada del lado izquierdo','Fijemos i,j arbitrarios. La entrada de B+C se suma en la misma posición (k,j).',r'[A(B+C)]_{ij}=\sum_{k=1}^{p}a_{ik}(b_{kj}+c_{kj})'),
 step('(b) Distribuimos y separamos las sumas','La distributividad real produce dos términos por cada k. Las dos sumas resultantes son las entradas de AB y de AC.',r'=\sum_k(a_{ik}b_{kj}+a_{ik}c_{kj})',r'=\sum_k a_{ik}b_{kj}+\sum_k a_{ik}c_{kj}=(AB+AC)_{ij}'),
 step('(c) Ahora distribuimos el otro factor','En (A+B)C se suma primero la entrada (i,k) del primer factor; no intercambiamos matrices.',r'[(A+B)C]_{ij}=\sum_k(a_{ik}+b_{ik})c_{kj}'),
 step('(c) Reconocemos AC y BC','Distribuimos en cada término y reunimos las sumas correspondientes.',r'=\sum_k a_{ik}c_{kj}+\sum_k b_{ik}c_{kj}=(AC+BC)_{ij}'),
 step('Conclusión formal','Las dos igualdades se cumplen en todas las entradas de matrices del mismo tamaño. Por tanto ambas distributividades quedan demostradas.')],
 'A(B+C)=AB+AC y (A+B)C=AC+BC.',eq_cases('Distribuimos a la izquierda',mul(a,add(b,c)),add(mul(a,b),mul(a,c)))+eq_cases('Distribuimos a la derecha',mul(add(a,b),c),add(mul(a,c),mul(b,c)))))
 A=M([[1,-2,3],[0,4,2]])
 L.append(proof(4,'Identidades de tamaños compatibles','Si A es m×n, demuestre IₘA=AIₙ=A.','A es una matriz real m×n; Iₘ e Iₙ son las identidades de los órdenes indicados.','Probar las dos igualdades para una matriz rectangular.','Una fila o columna de la identidad tiene un solo 1; todos los otros factores aportan cero.',[
 step('Aclaramos qué identidad se necesita','Iₘ multiplica por la izquierda porque tiene m columnas. Iₙ multiplica por la derecha porque tiene n filas. No se usa una misma identidad en ambos lados si m≠n.'),
 step('Producto por la izquierda','En la suma para (IₘA)ᵢⱼ, el factor de la identidad vale 1 solo cuando k=i. Todos los demás términos son cero.',r'(I_mA)_{ij}=\sum_{k=1}^{m}\delta_{ik}a_{kj}=a_{ij}'),
 step('Qué significa δ en esa fórmula','El símbolo δᵢₖ, llamado delta de Kronecker, vale 1 si i=k y 0 si i≠k. Es solo una forma breve de escribir las entradas de la identidad.',r'\delta_{ik}=\begin{cases}1&i=k\\0&i\ne k\end{cases}'),
 step('Producto por la derecha','Ahora el único término que sobrevive es k=j.',r'(AI_n)_{ij}=\sum_{k=1}^{n}a_{ik}\delta_{kj}=a_{ij}'),
 step('Conclusión formal','Para cada posición, las dos entradas son aᵢⱼ. Los tamaños también son m×n. Por tanto IₘA=AIₙ=A.')],
 'Las identidades de los órdenes correctos conservan A.',[closed_case('I₂A',mul(N('I₂',S.eye(2)),N('A',A))),closed_case('AI₃',mul(N('A',A),N('I₃',S.eye(3))))]))
 L.append(proof(5,'Leyes de potencias de una misma matriz','Para p,q enteros no negativos y A cuadrada, demuestre AᵖAᑫ=Aᵖ⁺ᑫ y (Aᵖ)ᑫ=Aᵖᑫ.','A es real n×n, n≥1; p,q≥0 son enteros; se define A⁰=Iₙ.','Probar ambas leyes incluyendo los exponentes cero.','Usar inducción: comprobar q=0 y explicar por qué el paso q→q+1 conserva cada igualdad.',[
 step('Definiciones y caso inicial de la primera ley','Aᵏ contiene k factores A. Para q=0, la identidad permite escribir la primera igualdad sin excepciones.',r'A^pA^0=A^pI_n=A^p=A^{p+0}'),
 step('Hipótesis inductiva para sumar exponentes','Supongamos para un q≥0 que AᵖAᑫ=Aᵖ⁺ᑫ. Multiplicamos una copia más de A a la derecha y usamos asociatividad.',r'A^pA^{q+1}=A^p(A^qA)=(A^pA^q)A=A^{p+q}A=A^{p+q+1}'),
 step('Primera conclusión','El caso inicial y el paso inductivo prueban AᵖAᑫ=Aᵖ⁺ᑫ para todo q≥0 y para el p arbitrario fijado.'),
 step('Caso inicial de la segunda ley','La matriz Aᵖ también es cuadrada. Su potencia cero es Iₙ, igual a A⁰.',r'(A^p)^0=I_n=A^{p\cdot0}'),
 step('Hipótesis y paso inductivo de la segunda ley','Supongamos (Aᵖ)ᑫ=Aᵖᑫ. Añadimos un factor Aᵖ y aplicamos la primera ley, que ya quedó probada.',r'(A^p)^{q+1}=(A^p)^qA^p=A^{pq}A^p=A^{pq+p}=A^{p(q+1)}'),
 step('Conclusión formal','Por inducción ambas leyes valen para todos los enteros p,q≥0. Solo se agrupan copias de la misma matriz; no se afirma una regla equivalente para dos matrices arbitrarias distintas.')],
 'AᵖAᑫ=Aᵖ⁺ᑫ y (Aᵖ)ᑫ=Aᵖᑫ.',eq_cases('Ejemplo p=2, q=2',mul(power(a,2),power(a,2)),power(a,4))+eq_cases('Potencia de una potencia',power(power(a,2),2),power(a,4))))
 D=M([[2,0],[0,-1]]);E0=M([[3,0],[0,4]]);dd,ee=N('A',D),N('B',E0)
 L.append(proof(6,'Potencia de un producto cuando los factores conmutan','Si AB=BA y p≥0 es entero, demuestre (AB)ᵖ=AᵖBᵖ.','A,B son reales n×n y AB=BA; p es un entero no negativo.','Probar la identidad sin suponer que matrices cualesquiera conmutan.','Primero mover A a través de una potencia de B; después aplicar inducción al producto AB.',[
 step('Lema: A conmuta con cada potencia de B','Para p=0, B⁰A=A=AB⁰. Si BᵖA=ABᵖ, entonces el paso siguiente usa BA=AB y luego la hipótesis.',r'B^{p+1}A=B^p(BA)=B^p(AB)=(B^pA)B=AB^{p+1}'),
 step('Caso inicial de la afirmación principal','Ambos lados son la identidad para p=0.',r'(AB)^0=I_n=A^0B^0'),
 step('Hipótesis inductiva','Supongamos que (AB)ᵖ=AᵖBᵖ para un p≥0. Escribimos la siguiente potencia añadiendo AB a la derecha.',r'(AB)^{p+1}=(AB)^pAB=A^pB^pAB'),
 step('Usamos exactamente la condición de conmutación','El lema permite intercambiar Bᵖ y A. Después agrupamos copias de una misma matriz.',r'A^pB^pAB=A^pAB^pB=A^{p+1}B^{p+1}'),
 step('Conclusión formal','La inducción prueba la identidad para todo p≥0. La hipótesis AB=BA se utilizó al mover factores; omitirla dejaría injustificado ese paso.')],
 '(AB)ᵖ=AᵖBᵖ bajo la hipótesis AB=BA.',eq_cases('Ejemplo con factores diagonales',power(mul(dd,ee),2),mul(power(dd,2),power(ee,2)))))
 L.append(proof(7,'Por qué dos matrices diagonales conmutan','Si A y B son diagonales n×n, demuestre AB=BA.','A=diag(a₁,…,aₙ) y B=diag(b₁,…,bₙ) con entradas reales.','Probar que ambos productos coinciden en la diagonal y fuera de ella.','En cada suma, los ceros de las diagonales eliminan todos los términos salvo, posiblemente, uno.',[
 step('Entrada fuera de la diagonal','Para i≠j, un término aᵢₖbₖⱼ solo podría ser no nulo si simultáneamente k=i y k=j. Eso es imposible. Entonces las dos matrices producto son diagonales.',r'(AB)_{ij}=0=(BA)_{ij}\quad(i\ne j)'),
 step('Entrada diagonal','Para i=j, el único término posible es k=i.',r'(AB)_{ii}=a_i b_i,\qquad(BA)_{ii}=b_i a_i'),
 step('Usamos conmutatividad de números, no de matrices','Los valores aᵢ y bᵢ son reales; sus productos sí conmutan. Por eso las entradas diagonales coinciden.',r'a_ib_i=b_ia_i'),
 step('Conclusión formal','Todas las entradas de AB y BA coinciden y sus tamaños son n×n. Por tanto AB=BA.')],
 'Los productos diagonales conmutan.',eq_cases('Productos diagonales',mul(dd,ee),mul(ee,dd))))
 for n,A,family,ans in [(8,M([[1,2],[2,1]]),M([['p','q'],['q','p']]),'B=[[p,q],[q,p]], excluyendo (p,q)=(0,0) y (1,0).'),(9,M([[1,2],[0,1]]),M([['p','q'],[0,'p']]),'B=[[p,q],[0,p]], excluyendo (p,q)=(0,0) y (1,0).')]:
  X=M([['a','b'],['c','d']]);comm=A*X-X*A
  conditions=[r'2c=2b\Longrightarrow c=b',r'2d=2a\Longrightarrow d=a'] if n==8 else [r'2c=0\Longrightarrow c=0',r'2d=2a\Longrightarrow d=a']
  sample=family.subs({'p':2,'q':3});cs=eq_cases('Ejemplo permitido p=2, q=3',mul(N('A',A),N('B',sample)),mul(N('B',sample),N('A',A)))
  L.append(proof(n,'Clasificar todas las matrices que conmutan con A','Determine B de 2×2, B≠O y B≠I₂, tal que AB=BA para la A indicada. ¿Cuántas existen?','B tiene entradas reales; A es la matriz concreta del enunciado.','Encontrar todas las B permitidas, no solamente un ejemplo.','Escribir cuatro incógnitas, comparar las cuatro posiciones y describir los parámetros libres.',[
   step('Empezamos con una matriz general','No suponemos que B sea simétrica ni triangular. Escribimos cuatro números desconocidos.',matrices=[mat('A',A),mat('B general',X)]),
   step('La igualdad impone condiciones entrada por entrada','Calculamos AB y BA mediante fila por columna. Como sus tamaños coinciden, deben coincidir sus cuatro casillas.',matrices=[mat('AB',A*X),mat('BA',X*A)]),
   step('Resolvemos las condiciones necesarias','De las entradas correspondientes obtenemos las igualdades siguientes. Dividir entre 2 es válido porque trabajamos con números reales.',*conditions),
   step('Describimos todos los candidatos y probamos suficiencia','Llamamos p y q a los valores que quedan libres. Sustituir esta familia en AB−BA da la matriz cero para cualquier p,q. Por tanto las condiciones encontradas son también suficientes.',matrices=[mat('Familia B',family)]),
   step('Excluimos los dos casos prohibidos','B=O corresponde a p=q=0. B=I₂ corresponde a p=1 y q=0. Se retiran solo esas dos parejas, no valores adicionales.'),
   step('Hay infinitas matrices distintas','Por ejemplo, fijar q=1 y variar p en los reales produce matrices permitidas distintas. Dos p distintos cambian la diagonal. Esta familia prueba que hay infinitas.')],ans,cs))
 theta=S.Symbol('theta',real=True)
 rot=lambda x:S.Matrix([[S.cos(x),S.sin(x)],[-S.sin(x),S.cos(x)]])
 cs=[]
 for degrees in [30,45,90]:
  A=rot(S.pi*degrees/180);C=Compiler();v=M([[1],[0]])
  for k in range(1,9):v,_=C.run(mul(N('Aθ',A),N('v'+str(k-1),v)));C.nodes[-1]['year']=k
  cs.append({'name':f'Giros sucesivos con θ={degrees}°','goal':'Cada producto aplica un giro horario más. El dibujo incorpora el nuevo vector solo al terminar sus dos coordenadas.','nodes':C.nodes,'result':mat('v8',v),'binary':False,'exploration':True,'plot':{'kind':'rotation','angle':degrees,'initial':[1,0]}})
 L.append(proof(10,'Potencias de una matriz de rotación','Para A=[[cos θ,sen θ],[−sen θ,cos θ]], calcule A² y A³, conjeture Aᵏ y demuestre su conjetura.','θ es real; k es un entero positivo.','Probar Aᵏ=[[cos(kθ),sen(kθ)],[−sen(kθ),cos(kθ)]].','Reconocer las fórmulas de suma de ángulos y después hacer una inducción completa.',[
 step('Interpretamos el signo del giro','La imagen de (1,0)ᵀ es (cos θ,−sen θ)ᵀ. Para θ positivo, la matriz representa un giro horario. Introducimos R(t) para la misma matriz con ángulo t.',r'R(t)=\begin{bmatrix}\cos t&\sin t\\-\sin t&\cos t\end{bmatrix}'),
 step('(a) Multiplicamos A por A','Las cuatro casillas se obtienen mediante fila por columna. Usamos cos²θ−sen²θ=cos2θ y 2senθcosθ=sen2θ.',r'A^2=\begin{bmatrix}\cos^2\theta-\sin^2\theta&2\sin\theta\cos\theta\\-2\sin\theta\cos\theta&\cos^2\theta-\sin^2\theta\end{bmatrix}=R(2\theta)'),
 step('Una identidad que explica las siguientes potencias','Multiplicamos R(u)R(v). Sus cuatro entradas usan las fórmulas cos(u+v)=cosu cosv−senu senv y sen(u+v)=senu cosv+cosu senv.',r'R(u)R(v)=\begin{bmatrix}\cos u\cos v-\sin u\sin v&\cos u\sin v+\sin u\cos v\\-\sin u\cos v-\cos u\sin v&-\sin u\sin v+\cos u\cos v\end{bmatrix}',r'=R(u+v)'),
 step('(b) Calculamos la tercera potencia','Aplicamos la identidad recién demostrada con u=2θ y v=θ.',r'A^3=A^2A=R(2\theta)R(\theta)=R(3\theta)'),
 step('(c) Conjetura y (d) caso inicial','Los primeros resultados sugieren Aᵏ=R(kθ). Para k=1 es cierta por la definición de A.',r'A^1=R(\theta)'),
 step('(d) Hipótesis y paso inductivo','Supongamos Aᵏ=R(kθ). Multiplicamos una copia más de A y usamos la identidad R(u)R(v), ya probada sin asumir la conjetura.',r'A^{k+1}=A^kA=R(k\theta)R(\theta)=R((k+1)\theta)'),
 step('Conclusión formal','El caso inicial y el paso inductivo prueban la fórmula para todos los enteros k≥1. Las pruebas con ángulos concretos del laboratorio ilustran la fórmula; no sustituyen la inducción.')],
 'A²=R(2θ), A³=R(3θ) y Aᵏ=R(kθ).',cs,graph={'kind':'rotation'}))
 L.append(proof(11,'Potencia de una matriz multiplicada por un escalar','Si p≥0 es entero y c es un escalar, demuestre (cA)ᵖ=cᵖAᵖ.','A es real n×n; c es real; p≥0 es entero. Las potencias cero se interpretan como productos vacíos.','Justificar la fórmula para todos los exponentes permitidos.','Separar el factor numérico en cada multiplicación y usar inducción.',[
 step('Caso p=0','Por definición una potencia cero de una matriz cuadrada es Iₙ. El factor c⁰ se interpreta como el producto vacío 1, también en el caso c=0 dentro de esta identidad algebraica.',r'(cA)^0=I_n=c^0A^0'),
 step('Hipótesis inductiva','Supongamos que para un p≥0 se cumple la igualdad. Añadimos el factor cA a la derecha.',r'(cA)^{p+1}=(cA)^p(cA)=c^pA^p(cA)'),
 step('Agrupamos los factores numéricos','El escalar c puede salir del producto matricial, por distributividad de la multiplicación de números en cada entrada.',r'c^pA^p(cA)=c^pc(A^pA)=c^{p+1}A^{p+1}'),
 step('Conclusión formal','La igualdad vale en p=0 y pasa de p a p+1. Por inducción vale para todo p≥0. No es la potencia de cada casilla: Aᵖ sigue siendo un producto matricial.')],
 '(cA)ᵖ=cᵖAᵖ.',eq_cases('Ejemplo c=−2, p=3',power(scale(-2,a),3),scale(-8,power(a,3)))))
 L.append(proof(12,'Las cuatro leyes de los escalares','Demuestre el teorema 1.3.','r,s son reales. Las matrices de las sumas tienen el mismo tamaño; los productos tienen tamaños compatibles.','Probar r(sA)=(rs)A, (r+s)A=rA+sA, r(A+B)=rA+rB y A(rB)=r(AB)=(rA)B.','Comparar una entrada arbitraria; en productos, sacar el factor constante de una suma finita.',[
 step('(a) Asociamos números reales','En la casilla (i,j), las dos matrices se reducen a la misma igualdad entre números.',r'[r(sA)]_{ij}=r(sa_{ij})=(rs)a_{ij}=[(rs)A]_{ij}'),
 step('(b) Distribuimos la suma de escalares','La distributividad real se aplica a cada entrada de A.',r'[(r+s)A]_{ij}=(r+s)a_{ij}=ra_{ij}+sa_{ij}=[rA+sA]_{ij}'),
 step('(c) Distribuimos el escalar sobre la suma de matrices','Usamos la definición de suma y después la distributividad de los números.',r'[r(A+B)]_{ij}=r(a_{ij}+b_{ij})=ra_{ij}+rb_{ij}=[rA+rB]_{ij}'),
 step('(d) El escalar dentro del segundo factor','Sean A de m×p y B de p×n. Como r no depende del índice k, sale de la suma.',r'[A(rB)]_{ij}=\sum_{k=1}^{p}a_{ik}(rb_{kj})=r\sum_{k=1}^{p}a_{ik}b_{kj}=[r(AB)]_{ij}'),
 step('(d) El escalar dentro del primer factor','La misma propiedad de los números permite colocarlo en A.',r'[(rA)B]_{ij}=\sum_{k=1}^{p}(ra_{ik})b_{kj}=r\sum_{k=1}^{p}a_{ik}b_{kj}'),
 step('Conclusión formal','Los índices eran arbitrarios y cada comparación se hizo entre matrices del mismo tamaño. Quedan demostrados los cuatro incisos; no se intercambiaron los factores A y B.')],
 'Las cuatro propiedades del teorema 1.3 son válidas.',eq_cases('Ejemplo de distribución',scale(-2,add(a,b)),add(scale(-2,a),scale(-2,b)))))
 L.append(proof(13,'Multiplicar por −1 produce el opuesto','Demuestre que (−1)A=−A.','A es real m×n. −A denota el único opuesto aditivo.','Identificar el producto por −1 con ese opuesto único.','Probar que su suma con A es cero y usar unicidad, no solo cambiar signos por costumbre.',[
 step('Entrada del producto por −1','Por definición de multiplicación por un escalar, su entrada (i,j) es −aᵢⱼ.',r'[(-1)A]_{ij}=(-1)a_{ij}=-a_{ij}'),
 step('Lo sumamos a A','Cada entrada de la suma queda en cero.',r'[A+(-1)A]_{ij}=a_{ij}-a_{ij}=0'),
 step('Usamos la unicidad del inverso aditivo','La matriz (−1)A tiene el tamaño correcto y satisface la condición que define al opuesto. T.1 probó que ese opuesto es único.'),
 step('Conclusión formal','Así (−1)A debe ser precisamente la matriz llamada −A.',r'(-1)A=-A')],
 '(−1)A=−A.',[closed_case('El opuesto entrada por entrada',scale(-1,a))]))
 L.append(proof(14,'Completar las pruebas de la transpuesta','Complete la demostración del teorema 1.4.','Matrices reales de tamaños compatibles y r real.','Probar los incisos (a), (b) y (d); incluir el argumento del producto para tener la regla completa.','La entrada (i,j) de una transpuesta es la entrada (j,i) de la matriz original.',[
 step('(a) Dos transposiciones','La primera cambia (i,j) por (j,i); la segunda recupera la posición original.',r'[(A^T)^T]_{ij}=(A^T)_{ji}=a_{ij}'),
 step('(b) Transponer una suma','El valor de la casilla se calcula antes o después del cambio de posición, con el mismo resultado.',r'[(A+B)^T]_{ij}=a_{ji}+b_{ji}=(A^T+B^T)_{ij}'),
 step('(d) Transponer un producto por un número','El escalar multiplica el valor; transponer solo cambia su posición.',r'[(rA)^T]_{ij}=ra_{ji}=(rA^T)_{ij}'),
 step('(c) Tamaños del producto transpuesto','Si A es m×p y B es p×n, (AB)ᵀ y BᵀAᵀ tienen tamaño n×m. Fijamos i≤n y j≤m.'),
 step('(c) Comparamos sus entradas con los índices correctos','La entrada que corresponde al transponer AB es (j,i), no (i,j). En la suma, aⱼₖ y bₖᵢ son números y podemos cambiar su orden.',r'[(AB)^T]_{ij}=(AB)_{ji}=\sum_{k=1}^{p}a_{jk}b_{ki}',r'=\sum_{k=1}^{p}(B^T)_{ik}(A^T)_{kj}=(B^TA^T)_{ij}'),
 step('Conclusión formal','La igualdad de entradas prueba los cuatro incisos. La regla del producto invierte el orden de los factores; las reglas de suma y de escalar no lo requieren.')],
 '(Aᵀ)ᵀ=A; (A+B)ᵀ=Aᵀ+Bᵀ; (AB)ᵀ=BᵀAᵀ; (rA)ᵀ=rAᵀ.',eq_cases('Producto y orden inverso',T(mul(a,b)),mul(T(b),T(a)))))
 L.append(proof(15,'Transponer una diferencia','Demuestre que (A−B)ᵀ=Aᵀ−Bᵀ.','A y B son reales m×n.','Probar la identidad para todas sus entradas.','Restar equivale a sumar el opuesto; también puede comprobarse directamente por índices.',[
 step('Fijamos una casilla de la transpuesta','Los dos lados tienen tamaño n×m. La casilla (i,j) del lado izquierdo proviene de la casilla (j,i) de A−B.',r'[(A-B)^T]_{ij}=(A-B)_{ji}'),
 step('Aplicamos la definición de resta','Restar matrices combina los dos números de la misma posición.',r'(A-B)_{ji}=a_{ji}-b_{ji}'),
 step('Reconocemos las transpuestas','aⱼᵢ y bⱼᵢ son las entradas (i,j) de Aᵀ y Bᵀ.',r'a_{ji}-b_{ji}=(A^T-B^T)_{ij}'),
 step('Conclusión formal','Los tamaños coinciden y la igualdad vale en toda casilla arbitraria. Por tanto las matrices son iguales.')],
 '(A−B)ᵀ=Aᵀ−Bᵀ.',eq_cases('Diferencia y transposición',T(sub(a,b)),sub(T(a),T(b)))))
 L.append(proof(16,'La transpuesta de cualquier potencia','Pruebe (a) (A²)ᵀ=(Aᵀ)²; (b) (A³)ᵀ=(Aᵀ)³; (c) decida la igualdad para k=4,5,…','A es real n×n; las potencias son matriciales.','Demostrar (Aᵏ)ᵀ=(Aᵀ)ᵏ para todo entero k≥1.','Al transponer se invierte el orden; como todos los factores son la misma matriz, el producto sigue siendo su potencia.',[
 step('(a) Dos factores','Aplicamos la regla de la transpuesta de un producto.',r'(A^2)^T=(AA)^T=A^TA^T=(A^T)^2'),
 step('(b) Tres factores','Separamos un factor y transponemos el producto; después usamos el inciso (a).',r'(A^3)^T=(A^2A)^T=A^T(A^2)^T=A^T(A^T)^2=(A^T)^3'),
 step('(c) Base de inducción','Para k=1, la afirmación es la identidad Aᵀ=Aᵀ.'),
 step('(c) Paso inductivo','Si (Aᵏ)ᵀ=(Aᵀ)ᵏ, entonces al añadir A se obtiene la fórmula siguiente.',r'(A^{k+1})^T=(A^kA)^T=A^T(A^k)^T=A^T(A^T)^k=(A^T)^{k+1}'),
 step('Conclusión formal','Por inducción la afirmación es cierta para todos los k≥1 y, en particular, para k=4,5,… . También vale para k=0 porque Iₙᵀ=Iₙ.')],
 'Cierto para todos los enteros k≥0.',eq_cases('Ejemplo k=3',T(power(a,3)),power(T(a),3))))
 sym=M([[1,2,3],[2,4,5],[3,5,6]]);skew=M([[0,2,-1],[-2,0,3],[1,-3,0]]);sN=N('S',sym);kN=N('K',skew)
 L.append(proof(17,'Simetría: demostración en los dos sentidos','Demuestre que A es simétrica si y solo si aᵢⱼ=aⱼᵢ para toda i,j.','A es real n×n.','Probar ambas implicaciones de la equivalencia.','Traducir la igualdad de matrices Aᵀ=A a igualdades de sus entradas.',[
 step('Definiciones que utilizaremos','Ser simétrica significa Aᵀ=A. Además, por definición de transpuesta, (Aᵀ)ᵢⱼ=aⱼᵢ.',r'A\text{ simétrica}\iff A^T=A'),
 step('Primer sentido: de simétrica a entradas reflejadas','Si Aᵀ=A, la igualdad de matrices exige igualdad en la posición (i,j).',r'a_{ji}=(A^T)_{ij}=a_{ij}'),
 step('Segundo sentido: de entradas reflejadas a simétrica','Si aᵢⱼ=aⱼᵢ para todo i,j, cada entrada de Aᵀ coincide con la de A.',r'(A^T)_{ij}=a_{ji}=a_{ij}'),
 step('Conclusión formal','Las matrices tienen igual tamaño y coinciden en todas sus posiciones. Esto prueba la segunda implicación y completa el «si y solo si».')],
 'A es simétrica ⇔ aᵢⱼ=aⱼᵢ para todo i,j.',[closed_case('Reflejar una matriz simétrica',T(sN))]))
 L.append(proof(18,'La transpuesta de una matriz simétrica','Si A es simétrica, demuestre que Aᵀ es simétrica.','A es real n×n y Aᵀ=A.','Probar que (Aᵀ)ᵀ=Aᵀ.','La transpuesta de la transpuesta recupera A y la hipótesis identifica A con Aᵀ.',[
 step('Escribimos la condición que hay que probar','La nueva matriz es Aᵀ. Para ser simétrica, debe coincidir con su propia transpuesta.',r'(A^T)^T=A^T'),
 step('Aplicamos la doble transposición','Para cualquier matriz se cumple (Aᵀ)ᵀ=A.',r'(A^T)^T=A'),
 step('Aplicamos la hipótesis, no una propiedad de cualquier A','Como la A del enunciado es simétrica, podemos sustituir A por Aᵀ.',r'(A^T)^T=A=A^T'),
 step('Conclusión formal','La matriz Aᵀ es cuadrada y coincide con su transpuesta; por definición es simétrica.')],
 'Aᵀ es simétrica.',[closed_case('Doble transposición del ejemplo',T(T(sN)))]))
 # T.19 conserva y corrige explícitamente la incompatibilidad del enunciado impreso.
 X=M([['a11','a12','a13'],['a21','a22','a23']]);cs=[closed_case('Columna '+str(j+1)+' mediante Ae'+str(j+1),mul(N('A simbólica',X),N('e'+str(j+1),S.eye(3)[:,j:j+1]))) for j in range(3)]
 L.append(proof(19,'Si anula todos los vectores, A es cero','El impreso dice: A es n×m y Ax=0 para todas las matrices x de n×1. Demuestre A=O.','Forma dimensionalmente coherente: A es real n×m y Ax=0 para todo x∈ℝᵐ.','Probar que todas las columnas y todas las entradas de A son cero.','Probar la hipótesis en cada vector de la base estándar, porque Aeⱼ selecciona la columna j.',[
 step('Ajustamos los tamaños antes de multiplicar','Con A de n×m, un vector que multiplica por la derecha debe tener m filas. La versión impresa n×1 solo es compatible si m=n. Probaremos la versión rectangular correcta; incluye como caso particular la cuadrada.'),
 step('Elegimos los vectores que permiten leer las columnas','Para cada j=1,…,m, sea eⱼ el vector con un 1 en la posición j y ceros en las demás. La hipótesis vale para él porque vale para todo vector de ℝᵐ.',r'A\mathbf e_j=\mathbf0\quad(1\leq j\leq m)'),
 step('Calculamos una componente arbitraria','En la suma solo sobrevive k=j, por las entradas de eⱼ.',r'(A\mathbf e_j)_i=\sum_{k=1}^{m}a_{ik}(\mathbf e_j)_k=a_{ij}'),
 step('Aplicamos el resultado de la hipótesis','Como Aeⱼ es el vector cero, su componente i vale cero. Esto obliga a aᵢⱼ=0 para todo i,j.',r'a_{ij}=(A\mathbf e_j)_i=0'),
 step('Conclusión formal','Todas las entradas son cero, así que A=Oₙ×ₘ. La palabra «todas» es esencial: que A anule un solo vector no basta.')],
 'A=O en la formulación dimensionalmente coherente.',cs,note='Errata de dimensiones en la imagen: para A de n×m, la hipótesis debe usar x de m×1. No se oculta esa corrección.'))
 X=M([['a','b'],['c','d']]);cs=[closed_case('Efecto sobre e'+str(j+1),mul(N('A simbólica',X),N('e'+str(j+1),S.eye(2)[:,j:j+1]))) for j in range(2)]
 L.append(proof(20,'Si conserva todos los vectores, A es la identidad','Sea A de n×n. Si Ax=x para todo x de n×1, demuestre A=Iₙ.','A es real n×n y conserva cada vector de ℝⁿ.','Identificar la columna j de A con la columna j de Iₙ.','Evaluar la hipótesis en los n vectores de la base estándar.',[
 step('Elegimos un vector que aísla una columna','Para cada j, el vector eⱼ tiene un 1 en la posición j y ceros en las otras. La hipótesis da Aeⱼ=eⱼ.',r'A\mathbf e_j=\mathbf e_j'),
 step('Interpretamos el lado izquierdo','La componente i de Aeⱼ es aᵢⱼ, por la definición de producto.',r'(A\mathbf e_j)_i=a_{ij}'),
 step('Interpretamos el lado derecho','La componente i de eⱼ es 1 si i=j y cero si i≠j.',r'a_{ij}=\delta_{ij}=\begin{cases}1&i=j\\0&i\ne j\end{cases}'),
 step('Conclusión formal','Las entradas encontradas son exactamente las de Iₙ. Como j e i fueron arbitrarios, A=Iₙ. Conservar un solo vector no justificaría esta conclusión.')],
 'A=Iₙ.',cs))
 X=M([['a11','a12','a13'],['a21','a22','a23']])
 L.append(proof(21,'AAᵀ=O obliga a que todas las entradas sean cero','Demuestre que si AAᵀ=O, entonces A=O.','A tiene entradas reales; puede ser m×n. La matriz AAᵀ es cero.','Probar que cada fila de A está formada por ceros.','Las entradas diagonales de AAᵀ son sumas de cuadrados reales, y esos sumandos no pueden cancelarse.',[
 step('Elegimos una entrada diagonal','Fijemos una fila i de A. La columna i de Aᵀ contiene esa misma fila escrita verticalmente.',r'(AA^T)_{ii}=\sum_{k=1}^{n}a_{ik}^2'),
 step('Usamos la hipótesis AAᵀ=O','La entrada diagonal correspondiente debe valer cero.',r'\sum_{k=1}^{n}a_{ik}^2=0'),
 step('Justificamos por qué cada cuadrado es cero','Cada cuadrado real es ≥0. Si hubiera un k con aᵢₖ≠0, su cuadrado sería positivo y la suma de todos los cuadrados también sería positiva, contradiciendo la igualdad anterior.',r'a_{ik}\ne0\Longrightarrow\sum_{\ell=1}^{n}a_{i\ell}^2\geq a_{ik}^2>0'),
 step('Cerramos para todas las filas','Ninguna entrada de la fila i puede ser no nula. Como i fue arbitrario, todas las filas y todas las entradas de A son cero.'),
 step('La hipótesis real es necesaria','Esta prueba utiliza cuadrados reales no negativos. Sobre números complejos, sin conjugación, A=[1,i] es no nula y AAᵀ=1+i²=0. En F₂ tampoco vale el argumento de positividad.')],
 'A=O para matrices reales.',[closed_case('Cómo se forman las sumas de cuadrados',mul(N('A simbólica',X),T(N('A simbólica',X))))]))
 L.append(proof(22,'Toda potencia de una matriz simétrica es simétrica','Si A es simétrica, demuestre que Aᵏ es simétrica para k=2,3,…','A es real n×n y Aᵀ=A; k es entero positivo.','Probar (Aᵏ)ᵀ=Aᵏ.','Combinar la regla de la transpuesta de una potencia con la hipótesis de simetría.',[
 step('Qué se debe comprobar','Aᵏ es cuadrada. Será simétrica si coincide con su transpuesta.',r'(A^k)^T=A^k'),
 step('Aplicamos la regla ya demostrada en T.16','Esa regla vale para cualquier matriz cuadrada, sin necesitar simetría.',r'(A^k)^T=(A^T)^k'),
 step('Ahora sí usamos que A es simétrica','Reemplazamos Aᵀ por A dentro de la potencia.',r'(A^T)^k=A^k'),
 step('Conclusión formal','La transpuesta de Aᵏ coincide con Aᵏ. Por definición es simétrica para cada k≥1; el caso k=0 también es simétrico porque A⁰=Iₙ.')],
 'Aᵏ es simétrica para todo entero k≥0.',[closed_case('Potencia de una matriz simétrica',power(sN,2))]))
 A=M([[1,0],[0,2]]);B=M([[2,1],[1,3]]);aa,bb=N('A',A),N('B',B)
 L.append(proof(23,'Suma y producto de matrices simétricas','Sean A y B simétricas. (a) Demuestre que A+B es simétrica. (b) Demuestre que AB es simétrica si y solo si AB=BA.','A,B son reales n×n y Aᵀ=A, Bᵀ=B.','Probar la suma y las dos implicaciones de la condición para el producto.','La transpuesta de un producto invierte el orden; ahí aparece la condición de conmutación.',[
 step('(a) Transponemos la suma','Usamos linealidad de la transpuesta y las dos hipótesis.',r'(A+B)^T=A^T+B^T=A+B'),
 step('(a) Cerramos el inciso','La suma es cuadrada y coincide con su transpuesta. Por tanto es simétrica.'),
 step('(b) Una identidad útil bajo las hipótesis','La regla del producto y la simetría de A y B implican la igualdad siguiente.',r'(AB)^T=B^TA^T=BA'),
 step('(b) Primer sentido: si AB es simétrica','Entonces (AB)ᵀ=AB. Combinando esa igualdad con la identidad anterior obtenemos BA=AB.',r'AB=(AB)^T=BA'),
 step('(b) Segundo sentido: si AB=BA','Sustituimos BA por AB en la identidad. Así se verifica la definición de simetría para AB.',r'(AB)^T=BA=AB'),
 step('Conclusión formal','La suma siempre es simétrica. El producto lo es exactamente cuando los factores conmutan; no basta con que ambos sean simétricos.')],
 'A+B es simétrica; AB es simétrica ⇔ AB=BA.',[closed_case('Suma simétrica',add(aa,bb)),closed_case('AB de dos simétricas que no conmutan',mul(aa,bb)),closed_case('BA para comparar',mul(bb,aa))]))
 L.append(proof(24,'Caracterización de las matrices antisimétricas','Una matriz A es antisimétrica si Aᵀ=−A. Demuestre la equivalencia con aᵢⱼ=−aⱼᵢ para todo i,j.','A es una matriz real n×n.','Probar ambas direcciones y explicar la diagonal.','Traducir la igualdad de matrices a las entradas y no olvidar el caso i=j.',[
 step('Primer sentido','Si Aᵀ=−A, al comparar la posición (i,j) obtenemos aⱼᵢ=−aᵢⱼ. Multiplicando por −1 queda la condición pedida.',r'a_{ji}=-a_{ij}\Longrightarrow a_{ij}=-a_{ji}'),
 step('Segundo sentido','Si aᵢⱼ=−aⱼᵢ para todos i,j, entonces en cada posición de la transpuesta se cumple la igualdad con −A.',r'(A^T)_{ij}=a_{ji}=-a_{ij}=(-A)_{ij}'),
 step('Qué pasa en la diagonal','Al elegir i=j aparece aᵢᵢ=−aᵢᵢ. Sumamos aᵢᵢ en ambos miembros y dividimos entre 2.',r'2a_{ii}=0\Longrightarrow a_{ii}=0'),
 step('Conclusión formal','Queda demostrada la equivalencia. Sobre los reales, toda matriz antisimétrica tiene diagonal cero; las parejas fuera de la diagonal son opuestas, no necesariamente iguales.')],
 'A es antisimétrica ⇔ aᵢⱼ=−aⱼᵢ.',[closed_case('Transponer una antisimétrica',T(kN)),closed_case('Su opuesto',scale(-1,kN))]))
 L.append(proof(25,'Matrices escalares que también son antisimétricas','Describa todas las matrices escalares antisimétricas.','A es real n×n, n≥1, y es escalar: A=rIₙ.','Determinar todos los valores permitidos de r.','Una matriz escalar es simétrica; para ser además antisimétrica debe ser su propio opuesto.',[
 step('Escribimos una matriz escalar general','Toda matriz escalar tiene ceros fuera de la diagonal y un mismo número r en toda la diagonal.',r'A=rI_n'),
 step('Imponemos la condición antisimétrica','Transponer una matriz diagonal la deja igual. Por tanto la condición exige rIₙ=−rIₙ.',r'A^T=A=-A\Longrightarrow rI_n=-rI_n'),
 step('Comparamos una entrada diagonal','Como n≥1, hay una entrada diagonal. Esa entrada satisface r=−r, así que r=0 sobre los reales.',r'2r=0\Longrightarrow r=0'),
 step('Suficiencia y clasificación','La matriz cero sí es escalar y satisface Oᵀ=O=−O. Por tanto la lista completa contiene únicamente Oₙ×ₙ.')],
 'Solo la matriz cero de cada orden.',[closed_case('Caso r=0',T(N('0I₂',S.zeros(2)))),closed_case('Caso r=2: no es antisimétrica',T(N('2I₂',2*S.eye(2))))]))
 L.append(proof(26,'AAᵀ y AᵀA siempre son simétricas','Si A es n×n, demuestre que AAᵀ y AᵀA son simétricas.','A es real n×n; no se supone que A sea simétrica.','Comprobar la transpuesta de ambos productos.','Usar inversión del orden y doble transposición.',[
 step('Producto AAᵀ','Al transponer, Aᵀ pasa primero y se transpone otra vez.',r'(AA^T)^T=(A^T)^TA^T=AA^T'),
 step('Producto AᵀA','La misma regla deja el producto original.',r'(A^TA)^T=A^T(A^T)^T=A^TA'),
 step('Tamaños y definición','Ambos productos son cuadrados y cada uno coincide con su propia transpuesta. Eso es exactamente ser simétrica.'),
 step('Conclusión formal','Los dos productos son simétricos, pero no necesariamente son iguales entre sí. La prueba también se extiende a A rectangular: los dos productos tendrán órdenes diferentes.')],
 'AAᵀ y AᵀA son simétricas.',[closed_case('AAᵀ',mul(a,T(a))),closed_case('AᵀA',mul(T(a),a))]))
 L.append(proof(27,'Construir una parte simétrica y una antisimétrica','Demuestre que (a) A+Aᵀ es simétrica y (b) A−Aᵀ es antisimétrica.','A es real n×n.','Probar las dos condiciones de transposición.','Transponer cada expresión y reagrupar con las reglas ya demostradas.',[
 step('(a) Transponemos la suma','Aplicamos la regla de suma y doble transposición.',r'(A+A^T)^T=A^T+(A^T)^T=A^T+A'),
 step('(a) Cerramos usando la conmutatividad de la suma','La suma de matrices sí conmuta, aunque el producto en general no.',r'A^T+A=A+A^T'),
 step('(b) Transponemos la diferencia','Aplicamos T.15 y la doble transposición.',r'(A-A^T)^T=A^T-A'),
 step('(b) Reconocemos el opuesto completo','El opuesto de A−Aᵀ es −A+Aᵀ, igual a Aᵀ−A.',r'A^T-A=-(A-A^T)'),
 step('Conclusión formal','La suma coincide con su transpuesta y la diferencia cambia al opuesto. Por definición, la primera es simétrica y la segunda antisimétrica.')],
 'A+Aᵀ es simétrica; A−Aᵀ es antisimétrica.',[closed_case('A+Aᵀ',add(a,T(a))),closed_case('A−Aᵀ',sub(a,T(a)))]))
 L.append(proof(28,'Descomposición única A=S+K','Demuestre que toda A de n×n puede escribirse de manera única como suma de una simétrica S y una antisimétrica K.','A tiene entradas reales. Se permite dividir entre 2.','Probar existencia de S,K y después demostrar su unicidad.','Sumar y restar A con su transpuesta permite separar las dos partes.',[
 step('Construimos las dos matrices','Definimos S y K con expresiones que tienen el mismo tamaño que A.',r'S=\frac{A+A^T}{2},\qquad K=\frac{A-A^T}{2}'),
 step('Verificamos el tipo de S','Transponer la suma conserva S.',r'S^T=\frac{A^T+A}{2}=S'),
 step('Verificamos el tipo de K','Transponer la diferencia da su opuesto.',r'K^T=\frac{A^T-A}{2}=-K'),
 step('Verificamos que realmente suman A','Los términos Aᵀ se cancelan y los dos A se suman.',r'S+K=\frac{A+A^T+A-A^T}{2}=A'),
 step('Unicidad: partimos de cualquier otra descomposición','Si A=S₁+K₁, con S₁ᵀ=S₁ y K₁ᵀ=−K₁, entonces al transponer obtenemos Aᵀ=S₁−K₁.',r'A=S_1+K_1,\qquad A^T=S_1-K_1'),
 step('Las dos partes están obligadas a ser las construidas','Sumar las dos igualdades fuerza S₁; restarlas fuerza K₁. No hay libertad para otra elección.',r'2S_1=A+A^T\Longrightarrow S_1=S',r'2K_1=A-A^T\Longrightarrow K_1=K'),
 step('Conclusión formal','Las fórmulas producen una descomposición válida y cualquier descomposición válida coincide con ella. Quedan probadas existencia y unicidad.')],
 'S=(A+Aᵀ)/2 y K=(A−Aᵀ)/2, de manera única.',[closed_case('Parte simétrica',scale(S.Rational(1,2),add(a,T(a)))),closed_case('Parte antisimétrica',scale(S.Rational(1,2),sub(a,T(a)))),closed_case('S+K',add(scale(S.Rational(1,2),add(a,T(a))),scale(S.Rational(1,2),sub(a,T(a)))))]))
 L.append(proof(29,'Toda matriz escalar es rIₙ','Demuestre que si A es una matriz escalar n×n, entonces A=rIₙ para algún real r.','A es escalar de orden n≥1: diagonal constante y entradas exteriores cero.','Encontrar r y comprobar igualdad en todas las posiciones.','Comparar la diagonal y las entradas fuera de ella.',[
 step('Elegimos el número común de la diagonal','Por definición de matriz escalar, existe un real r que aparece en cada posición diagonal de A.',r'a_{ii}=r\quad(1\leq i\leq n)'),
 step('Comparamos las diagonales','La entrada diagonal de rIₙ es r·1=r, igual a la de A.',r'(rI_n)_{ii}=r=a_{ii}'),
 step('Comparamos fuera de la diagonal','La identidad tiene cero en esas posiciones, y una matriz escalar también.',r'(rI_n)_{ij}=r\cdot0=0=a_{ij}\quad(i\ne j)'),
 step('Conclusión formal','Las matrices tienen el mismo tamaño y todas sus entradas coinciden. Por tanto A=rIₙ. El número r queda determinado por cualquier entrada diagonal.')],
 'A=rIₙ, con r igual al valor común de su diagonal.',[closed_case('Una matriz escalar',scale(-3,I))]))
 L.append(proof(30,'La identidad es simétrica','Demuestre Iₙᵀ=Iₙ.','n es un entero positivo.','Probar que transponer no cambia ninguna entrada de Iₙ.','La condición i=j no cambia al intercambiar los índices.',[
 step('Escribimos las entradas de la identidad','La entrada (i,j) es 1 cuando i=j y 0 en otro caso.',r'(I_n)_{ij}=\delta_{ij}'),
 step('Escribimos la entrada de la transpuesta','Intercambiar i y j produce δⱼᵢ.',r'(I_n^T)_{ij}=(I_n)_{ji}=\delta_{ji}'),
 step('Comparamos los dos casos','Si i=j, ambos deltas son 1. Si i≠j, ambos son 0. Por tanto δⱼᵢ=δᵢⱼ.'),
 step('Conclusión formal','La igualdad de todas las entradas prueba Iₙᵀ=Iₙ. Así la identidad es simétrica para cualquier orden.')],
 'Iₙᵀ=Iₙ.',[closed_case('Transposición de I₃',T(N('I₃',S.eye(3))))]))
 L.append(proof(31,'Producto por un escalar igual a cero','Si rA=O para una matriz A de m×n, demuestre r=0 o A=O.','A es real m×n, r es real y rA=O.','Justificar una disyunción que no exige que las alternativas sean excluyentes.','Separar r=0 de r≠0; solo en el segundo caso podemos dividir.',[
 step('Primer caso: r=0','Ya se cumple la primera alternativa. No necesitamos deducir que A sea cero; podría no serlo.'),
 step('Segundo caso: r≠0','La igualdad de matrices obliga a que cada entrada de rA sea cero.',r'ra_{ij}=0\quad\text{para todo }i,j'),
 step('Dividimos en el caso permitido','Como r no es cero, dividir la igualdad numérica entre r es válido.',r'a_{ij}=\frac0r=0'),
 step('Conclusión formal','En el segundo caso todas las entradas son cero y A=O. Los dos casos agotan las posibilidades. También es posible que r=0 y A=O simultáneamente.')],
 'r=0 o A=O.',[closed_case('r=0 con A no nula',scale(0,a)),closed_case('r≠0 con A nula',scale(3,N('O',S.zeros(2))))]))
 A=M([[1,1],[2,2]]);u=M([[2],[0]]);v=M([[0],[2]]);cs=[]
 for t in [S.Integer(-1),S.Integer(0),S.Rational(1,2),S.Integer(1),S.Integer(2)]:
  w=(1-t)*u+t*v;cs.append(closed_case('t='+str(t)+': combinación de dos soluciones',add(scale(1-t,N('u₁',u)),scale(t,N('u₂',v))),goal='Los coeficientes son 1−t y t; su suma siempre es 1.',plot={'kind':'affine','t':str(t),'point':[float(x) for x in w],'initial':[2,0]}))
 L.append(proof(32,'Más de una solución implica infinitas','Demuestre que si Ax=b tiene más de una solución, tiene infinitas. Use combinaciones cuyos coeficientes sumen 1.','A es real m×n; u₁ y u₂ son soluciones distintas: Au₁=Au₂=b.','Construir infinitas soluciones y demostrar que son distintas.','Recorrer la recta que pasa por las dos soluciones; la suma 1 de los coeficientes conserva b.',[
 step('Definimos una familia con un parámetro libre','Para cada real t tomamos wₜ=(1−t)u₁+tu₂. Los coeficientes suman 1, incluso si t es negativo o mayor que 1.',r'\mathbf w_t=(1-t)\mathbf u_1+t\mathbf u_2'),
 step('Comprobamos que cada miembro es solución','Usamos la distributividad del producto y las igualdades de la hipótesis.',r'A\mathbf w_t=(1-t)A\mathbf u_1+tA\mathbf u_2=(1-t)\mathbf b+t\mathbf b=\mathbf b'),
 step('No basta con escribir muchos parámetros','Tenemos que probar que parámetros distintos producen vectores distintos. Si wₜ=wₛ, al restar se obtiene la igualdad siguiente.',r'(t-s)(\mathbf u_2-\mathbf u_1)=\mathbf0'),
 step('Usamos que las soluciones iniciales eran distintas','Como u₂−u₁≠0, alguna coordenada j no es cero. En esa coordenada, dividir entre la diferencia permite concluir t−s=0.',r'(t-s)(u_{2j}-u_{1j})=0,\quad u_{2j}-u_{1j}\ne0\Longrightarrow t=s'),
 step('Conclusión formal','La aplicación t↦wₜ es inyectiva y todos sus valores son soluciones. Como hay infinitos números reales, hay infinitas soluciones. No se usa solo la observación de dos o tres ejemplos.')],
 'El sistema tiene infinitas soluciones.',cs,graph={'kind':'affine','matrix':rows(A),'rhs':[2,4]}))
 X=M([['a','b'],['c','d']]);E11=M([[1,0],[0,0]]);E12=M([[0,1],[0,0]])
 L.append(proof(33,'Matrices que conmutan con todas las 2×2','Determine todas las matrices A de 2×2 tales que AB=BA para cualquier matriz B de 2×2.','A tiene entradas reales y conmuta con cada matriz real B de orden 2.','Clasificar exactamente todas las A.','La hipótesis universal permite elegir dos matrices B que obligan a que A sea escalar.',[
 step('Partimos de cuatro entradas desconocidas','Escribimos A sin suponer ningún patrón.',matrices=[mat('A',X)]),
 step('Primera elección: E₁₁','Aplicamos la hipótesis a B=E₁₁. Los dos productos obligan a b=c=0.',matrices=[mat('E₁₁',E11),mat('AE₁₁',X*E11),mat('E₁₁A',E11*X)]),
 step('Segunda elección: E₁₂','A ya es diagonal. La igualdad con E₁₂ obliga a que sus dos entradas diagonales sean iguales.',math=[r'\begin{bmatrix}a&0\\0&d\end{bmatrix}E_{12}=\begin{bmatrix}0&a\\0&0\end{bmatrix}',r'E_{12}\begin{bmatrix}a&0\\0&d\end{bmatrix}=\begin{bmatrix}0&d\\0&0\end{bmatrix}',r'a=d']),
 step('Condición necesaria','Toda A de la clasificación tiene entonces la forma rI₂, para r real.'),
 step('Comprobamos la suficiencia para cualquier B','Si A=rI₂, la identidad y las leyes de escalares dan AB=rB=BA. Esta verificación vale para toda B, no solo para las dos matrices de prueba.',r'(rI_2)B=rB=B(rI_2)'),
 step('Conclusión formal','Las matrices buscadas son exactamente las matrices escalares de orden 2. Hay infinitas, una para cada real r.')],
 'A=rI₂ para cualquier r∈ℝ.',[closed_case('AE₁₁',mul(N('A simbólica',X),N('E₁₁',E11))),closed_case('E₁₁A',mul(N('E₁₁',E11),N('A simbólica',X))),closed_case('AE₁₂',mul(N('A diagonal',S.diag(S.Symbol('a'),S.Symbol('d'))),N('E₁₂',E12)))]))
 L.append(proof(34,'La transpuesta de una antisimétrica','Si A es antisimétrica, ¿qué tipo de matriz es Aᵀ? Justifique.','A es real n×n y Aᵀ=−A.','Determinar el tipo de Aᵀ mediante su definición.','Probar que la transpuesta de Aᵀ es el opuesto de Aᵀ.',[
 step('Llamamos B a la matriz que estudiamos','Definimos B=Aᵀ. Para que sea antisimétrica debemos probar Bᵀ=−B.'),
 step('Calculamos su transpuesta','Por doble transposición, Bᵀ=A.',r'B^T=(A^T)^T=A'),
 step('Reescribimos la hipótesis','De Aᵀ=−A se deduce −Aᵀ=A. Por tanto A=−B.',r'B^T=A=-A^T=-B'),
 step('Conclusión formal','B es antisimétrica. Puede ser además simétrica solo en el caso A=O sobre los reales.')],
 'Aᵀ es antisimétrica.',[closed_case('Transpuesta del ejemplo',T(kN)),closed_case('Opuesto de esa transpuesta',scale(-1,T(kN)))]))
 L.append(proof(35,'Combinaciones lineales de simétricas','¿Qué tipo de matriz es una combinación lineal de matrices simétricas? Justifique.','A₁,…,Aₖ son simétricas reales del mismo orden y c₁,…,cₖ son escalares reales.','Probar que toda combinación lineal finita es simétrica.','La transpuesta respeta sumas finitas y productos por números.',[
 step('Escribimos la combinación','Una combinación lineal multiplica cada matriz por un número y suma los resultados.',r'S=\sum_{\ell=1}^{k}c_\ell A_\ell'),
 step('Transponemos término a término','Aplicar repetidamente las reglas de suma y escalar produce la expresión siguiente.',r'S^T=\sum_{\ell=1}^{k}c_\ell A_\ell^T'),
 step('Usamos cada hipótesis de simetría','Para todo ℓ, Aℓᵀ=Aℓ. Sustituirlo devuelve la misma suma original.',r'S^T=\sum_{\ell=1}^{k}c_\ell A_\ell=S'),
 step('Conclusión formal','S es cuadrada y coincide con su transpuesta; por definición es simétrica. No hace falta que los coeficientes sean positivos ni que sumen 1.')],
 'La combinación lineal es simétrica.',[closed_case('Ejemplo de combinación',add(scale(2,sN),scale(-3,N('I₃',S.eye(3)))))]))
 L.append(proof(36,'Combinaciones lineales de matrices escalares','¿Qué tipo de matriz es una combinación lineal de matrices escalares? Justifique.','Aℓ=rℓIₙ son matrices escalares del mismo orden; cℓ son coeficientes reales.','Probar que la combinación vuelve a ser una matriz escalar.','Sacar la identidad común de una suma de múltiplos.',[
 step('Expresamos cada matriz usando la identidad','Por T.29 cada matriz escalar del orden n tiene la forma rℓIₙ.'),
 step('Sustituimos en la combinación','Multiplicamos los dos números de cada término.',r'\sum_{\ell=1}^{k}c_\ell A_\ell=\sum_{\ell=1}^{k}c_\ell r_\ell I_n'),
 step('Reunimos el coeficiente común','La distributividad permite reunir todos los números delante de una sola identidad.',r'=\left(\sum_{\ell=1}^{k}c_\ell r_\ell\right)I_n'),
 step('Conclusión formal','La expresión final es un número real por Iₙ; por tanto es una matriz escalar. Incluye la matriz cero cuando el coeficiente total es cero.')],
 'La combinación lineal es escalar.',[closed_case('Dos matrices escalares',add(scale(2,N('3I₂',3*S.eye(2))),scale(-3,N('−I₂',-S.eye(2)))))]))
 L.append(proof(37,'Una diagonal constante actúa como un escalar','Si aᵢᵢ=r y aᵢⱼ=0 para i≠j, demuestre AB=rB para toda B de n×n.','A tiene diagonal constante r y ceros fuera de ella; B es una matriz real arbitraria del mismo orden.','Probar la igualdad en cada posición.','En la suma del producto, el único factor de A posiblemente no nulo es el de la diagonal.',[
 step('Fijamos una entrada cualquiera del producto','El índice k recorre las columnas de A y las filas de B.',r'(AB)_{ij}=\sum_{k=1}^{n}a_{ik}b_{kj}'),
 step('Usamos los ceros de A','Si k≠i, aᵢₖ=0. Por eso solo sobrevive el término k=i.',r'(AB)_{ij}=a_{ii}b_{ij}=rb_{ij}'),
 step('Reconocemos el producto por el número r','La entrada (i,j) de rB es precisamente rbᵢⱼ.',r'(AB)_{ij}=(rB)_{ij}'),
 step('Conclusión formal','Los índices eran arbitrarios y ambos lados tienen orden n. Así AB=rB para toda B permitida. No se utilizó ninguna propiedad especial de las entradas de B.')],
 'AB=rB.',[closed_case('Múltiplo de la identidad por B',mul(N('−2I₂',-2*S.eye(2)),b))]))
 B=M([[1,0],[1,1]])
 L.append(proof(38,'En binario cada matriz es su propio opuesto','Si A es una matriz binaria n×n, demuestre −A=A.','Las entradas pertenecen a F₂={0,1} y las operaciones se reducen módulo 2.','Identificar el opuesto aditivo de cada entrada y de toda la matriz.','Solo hay dos bits: ambos sumados consigo mismos dan cero en F₂.',[
 step('Revisamos todos los valores de una entrada','Si a=0, entonces a+a=0. Si a=1, la suma usual 2 tiene resto 0. Estos dos casos son exhaustivos.',r'0+0=0,\qquad1+1=0\quad\text{en }\mathbb F_2'),
 step('Pasamos de las entradas a la matriz','Cada entrada de A+A es cero, así que la suma es la matriz cero del mismo orden.',r'A+A=O'),
 step('Usamos la definición del opuesto','El opuesto −A es la única matriz D que cumple A+D=O. La igualdad anterior muestra que la propia A cumple esa condición.'),
 step('Conclusión formal','Por unicidad del opuesto, −A=A. Esta afirmación es propia de F₂; no se aplica a una matriz real no nula.')],
 '−A=A en F₂.',[closed_case('Opuesto binario',scale(-1,N('A',B)),True),closed_case('A+A módulo 2',add(N('A',B),N('A',B)),True)],domain='F2'))
 from itertools import product
 for n,target in [(39,S.zeros(2)),(40,S.eye(2))]:
  matches=[];cases=[];table=[]
  for bits in product([0,1],repeat=4):
   A=M([bits[:2],bits[2:]]);square=(A*A).applyfunc(lambda z:z%2);ok=square==target
   table.append([''.join(map(str,bits)),str(square.tolist()),'Sí' if ok else 'No'])
   if ok:matches.append(A)
   cases.append(closed_case('Bits '+''.join(map(str,bits)),power(N('A',A),2),True,goal='Probamos esta matriz con el mismo procedimiento. El resultado debe compararse con '+('O₂×₂.' if n==39 else 'I₂.')))
  assert len(matches)==4
  equations=[r'a+bc=0,\quad d+bc=0',r'b(a+d)=0,\quad c(a+d)=0'] if n==39 else [r'a+bc=1,\quad d+bc=1',r'b(a+d)=0,\quad c(a+d)=0']
  familydesc='a=d=bc' if n==39 else 'a=d=1+bc (módulo 2)'
  L.append(proof(n,'Clasificación exhaustiva de cuadrados binarios','Determine todas las matrices binarias A de 2×2 tales que A²='+('O.' if n==39 else 'I₂.'),'A=[[a,b],[c,d]], con cada entrada igual a 0 o 1; operaciones en F₂.','Encontrar la lista completa y demostrar que no falta ninguna matriz.','Calcular el cuadrado general y separar los dos casos bc=0 y bc=1.',[
   step('Hay exactamente dieciséis candidatos','Cada una de las cuatro posiciones admite dos valores independientes. Por tanto hay 2⁴=16 matrices, que pueden ordenarse por los bits a,b,c,d.',r'A=\begin{bmatrix}a&b\\c&d\end{bmatrix}'),
   step('Calculamos el cuadrado antes de clasificar','En F₂ se cumple a²=a y d²=d, porque las entradas son bits.',r'A^2=\begin{bmatrix}a+bc&b(a+d)\\c(a+d)&d+bc\end{bmatrix}'),
   step('Igualamos todas las entradas con el objetivo','No basta con revisar una diagonal. Deben cumplirse las cuatro ecuaciones.',*equations),
   step('Resolvemos las dos ecuaciones diagonales','Estas fuerzan '+familydesc+'. En particular, a=d y por tanto a+d=0 en F₂. Las otras dos ecuaciones quedan automáticamente satisfechas.'),
   step('Separamos los dos casos posibles de bc','Si bc=0, (b,c) puede ser (0,0), (1,0) o (0,1): tres matrices. Si bc=1, necesariamente b=c=1: una cuarta matriz. No existe otro par de bits.'),
   step('Lista completa de soluciones','Cada matriz de la lista satisface las condiciones deducidas, por lo que su cuadrado es el objetivo. Los dos casos anteriores agotan los dieciséis candidatos.',matrices=[mat('Solución '+str(i+1),A) for i,A in enumerate(matches)]),
   step('Comprobación exhaustiva independiente','Ordenamos cada candidato por sus cuatro bits y calculamos su cuadrado. Esta tabla confirma las cuatro soluciones y descarta todas las demás.',table={'headers':['Bits a b c d','A² módulo 2','¿Cumple?'],'rows':table})],
 'Hay exactamente cuatro matrices: '+str([A.tolist() for A in matches])+'.',cases,domain='F2'))
 assert len(L)==40
 return L
