"""Colección con índice y marcadores, guía breve y fuente LaTeX editable."""
from pathlib import Path
import json,html,re
import fitz
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4,landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=Path(__file__).resolve().parents[1];D=json.loads((R/'lecciones.json').read_text());DEST=R/'descargas'
from matplotlib import get_data_path
FONTDIR=Path(get_data_path())/'fonts/ttf'
pdfmetrics.registerFont(TTFont('DejaVu',str(FONTDIR/'DejaVuSans.ttf')));pdfmetrics.registerFont(TTFont('DejaVu-Bold',str(FONTDIR/'DejaVuSans-Bold.ttf')))
styles=getSampleStyleSheet();styles.add(ParagraphStyle('normal14',fontName='DejaVu',fontSize=10,leading=16,spaceAfter=10));styles.add(ParagraphStyle('title14',fontName='DejaVu-Bold',fontSize=28,leading=35,textColor=colors.HexColor('#237344'),spaceAfter=20));styles.add(ParagraphStyle('head14',fontName='DejaVu-Bold',fontSize=15,leading=20,textColor=colors.HexColor('#237344'),spaceBefore=15,spaceAfter=10))
def P(t,style='normal14'):return Paragraph(t,styles[style])
def footer(canvas,doc):canvas.saveState();canvas.setFont('DejaVu',8);canvas.setFillColor(colors.HexColor('#627268'));canvas.drawString(36,24,'Álgebra 1.4 · Proyecto independiente');canvas.drawRightString(doc.pagesize[0]-36,24,str(doc.page));canvas.restoreState()
# Guía autónoma, útil incluso antes de abrir la página.
story=[P('Empieza aquí<br/>Sección 1.4','title14'),P('Un proyecto separado para estudiar, practicar y publicar.'),P('1. Abre la página','head14'),P('Extrae el ZIP exterior con «Extraer todo». Abre index.html en Chrome o Edge. No necesitas instalar programas para estudiar ni tener conexión.'),P('2. Aprende con las explicaciones','head14'),P('Elige un ejercicio a la izquierda. Lee toda la solución o cambia a un paso por vez. En los teóricos encontrarás las hipótesis, lo que se debe demostrar y una prueba con conclusión. Los ejemplos ilustrativos se identifican como tales.'),P('3. Usa el laboratorio','head14'),P('En computadora está a la derecha. Siguiente selecciona una casilla, calcula un producto, lo añade a la suma y guarda el resultado. Los ? son entradas pendientes. Anterior retrocede; Reiniciar borra el caso actual. Al finalizar, la misma flecha lleva al siguiente inciso.'),P('4. Observa qué cambia','head14'),P('Las matrices tienen filas y columnas numeradas. Las gráficas añaden puntos o vectores al completar sus coordenadas. Puedes acercar, desplazar y girar las figuras 3D. En los teóricos puedes alternar entre recorrer el argumento y practicar cuentas.'),P('5. Descarga','head14'),P('PDF completo reúne los 76 ejercicios; PDF del ejercicio descarga solo el seleccionado, con sus incisos. La portada incluye MATLAB, LaTeX y fuentes para VS Code.'),PageBreak(),P('Publícalo por separado','title14'),P('Crea un repositorio público nuevo, por ejemplo Algebra_1_4. Conserva tu repositorio anterior.'),P('1. Sube index.html','head14'),P('En el repositorio nuevo, pulsa Add file → Upload files → choose your files. Elige index.html. Escribe «Agregar sección 1.4» en el primer cuadro de Commit changes y pulsa el botón verde.'),P('2. Sube los demás archivos','head14'),P('Repite la subida y el commit para cada archivo de la carpeta extraída, uno por vez. Conserva los nombres, incluido .nojekyll. ARCHIVOS_GITHUB.txt contiene la lista exacta. Los archivos de descarga y Fuentes_VSCode.zip se mantienen junto a index.html; no extraigas ese ZIP interior para publicar.'),P('3. Activa GitHub Pages','head14'),P('Ve a Settings → Pages. Source: Deploy from a branch. Branch: main. Carpeta: /(root). Pulsa Save. Abre el enlace que GitHub muestre cuando termine.'),P('4. Comprueba la publicación','head14'),P('Abre un ejercicio, avanza unas cuentas, elige el tema verde y descarga un PDF individual. Si falta una descarga, revisa que todos los archivos estén en la raíz y sus nombres coincidan con los originales.'),P('Para editar en VS Code','head14'),P('Extrae Fuentes_VSCode.zip en otra carpeta y abre esa carpeta con VS Code. La web ya está lista; solo necesitas instalar las dependencias si quieres regenerar datos, documentos o empaquetados.'),P('Más ayuda','head14'),P('LEEME.md explica los controles, la publicación y las precisiones matemáticas. REVISION.md describe la validación. Ningún archivo de esta entrega sustituye las secciones 1.1–1.3.')]
SimpleDocTemplate(str(R/'Guia_1_4.pdf'),pagesize=A4,leftMargin=42,rightMargin=42,topMargin=42,bottomMargin=40).build(story,onFirstPage=footer,onLaterPages=footer)
# Índice con los números definitivos; el índice siempre ocupa cuatro páginas.
counts={d['key']:len(fitz.open(DEST/(d['key']+'.pdf'))) for d in D};starts={};at=5
for d in D:starts[d['key']]=at;at+=counts[d['key']]
story=[P('Álgebra<br/>Sección 1.4','title14'),Spacer(1,14),P('Aula de matrices','head14'),P('25 ejercicios prácticos · 40 teóricos · 11 MATLAB'),P('Soluciones desarrolladas con operaciones completas, demostraciones formales y vocabulario para empezar desde cero.'),Spacer(1,18),P('Cómo leer esta colección','head14'),P('Cada ejercicio comienza con su enunciado y datos, continúa con la explicación y termina con una conclusión. Las ilustraciones numéricas de los teóricos se distinguen de la prueba general. Los gráficos impresos muestran resultados completos de referencia; la construcción progresiva y los controles se encuentran en index.html.'),P('Las operaciones binarias se realizan en F₂. Los ejercicios de matrices reales conservan sus hipótesis. Las correcciones editoriales aparecen en el ejercicio al que afectan.'),P('Los marcadores del lector PDF permiten saltar a cualquier ejercicio. El índice siguiente indica su página de inicio.'),PageBreak()]
for group,title in [('practicos','Índice · prácticos'),('teoricos','Índice · teóricos'),('matlab','Índice · MATLAB')]:
 story.append(P(title,'title14'))
 # Dos columnas para los cuarenta teóricos, mantener cada grupo en una página.
 entries=[d for d in D if d['group']==group];rows=[]
 if group=='teoricos':
  for i in range(20):rows.append([P(f"<b>{html.escape(entries[i]['id'])}</b> · {html.escape(entries[i]['title'])}", 'normal14'),str(starts[entries[i]['key']]),P(f"<b>{html.escape(entries[i+20]['id'])}</b> · {html.escape(entries[i+20]['title'])}",'normal14'),str(starts[entries[i+20]['key']])])
  widths=[320,30,320,30]
 else:
  for d in entries:rows.append([P(f"<b>{html.escape(d['id'])}</b> · {html.escape(d['title'])}",'normal14'),str(starts[d['key']])])
  widths=[650,50]
 t=Table(rows,colWidths=widths);t.setStyle(TableStyle([('FONTNAME',(0,0),(-1,-1),'DejaVu'),('FONTSIZE',(0,0),(-1,-1),9),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,-1),.3,colors.HexColor('#e2e9e3')),('BOTTOMPADDING',(0,0),(-1,-1),3),('TOPPADDING',(0,0),(-1,-1),2)]));story.append(t)
 if group!='matlab':story.append(PageBreak())
# Índices en paisaje A4: ajustar el tamaño de texto para que los grupos no desborden.
for row in story:
 if isinstance(row,Table):
  for data in row._cellvalues:
   for c in data:
    if isinstance(c,Paragraph):c.style=ParagraphStyle('toc',fontName='DejaVu',fontSize=8.2,leading=11)
SimpleDocTemplate(str(DEST/'portada_indice.pdf'),pagesize=landscape(A4),leftMargin=48,rightMargin=48,topMargin=36,bottomMargin=36).build(story,onFirstPage=footer,onLaterPages=footer)
cover=fitz.open(DEST/'portada_indice.pdf');assert len(cover)==4,len(cover)
book=fitz.open();book.insert_pdf(cover);toc=[[1,'Portada e índice',1]];lastgroup=None
for d in D:
 if d['group']!=lastgroup:toc.append([1,{'practicos':'Prácticos','teoricos':'Teóricos','matlab':'MATLAB'}[d['group']],len(book)+1]);lastgroup=d['group']
 assert len(book)+1==starts[d['key']]
 toc.append([2,d['id']+'. '+d['title'],len(book)+1]);doc=fitz.open(DEST/(d['key']+'.pdf'));book.insert_pdf(doc)
book.set_toc(toc);book.set_metadata({'title':'Álgebra 1.4 · Colección completa','author':'Aula de matrices','subject':'76 ejercicios con soluciones y demostraciones'});book.save(R/'Coleccion_1_4.pdf',garbage=4,deflate=True)
# Fuente editorial: Unicode en texto, matemáticas en amsmath. Compilar con LuaLaTeX.
def esc(s):
 return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in str(s))
def latex_step(s):
 out='\n\\subsection*{'+esc(s['title'])+'}\n'+esc(s['text'])+'\n'
 for a in s.get('actions',[]):out+=esc(a['text'])+'\n'+('\\['+a['math']+'\\]\n' if a.get('math') else '')
 for m in s.get('math',[]):out+='\\['+m+'\\]\n'
 for mat in s.get('matrices',[]):out+='\\noindent '+esc(mat['name'])+'\\['+mat['tex']+'\\]\n'
 if s.get('table'):
  t=s['table'];out+='\\begin{longtable}{'+'p{'+str(15/len(t['headers']))+'cm}'*len(t['headers'])+'}\n'+' & '.join(esc(h) for h in t['headers'])+r'\\\hline'+'\n'
  for row in t['rows']:out+=' & '.join((v if str(v).startswith('$') and str(v).endswith('$') else esc(v)) for v in row)+r'\\'+'\n'
  out+='\\end{longtable}\n'
 if s.get('conclusion'):out+='\\textbf{'+esc(s['conclusion'])+'}\n'
 return out
tex=r'''\documentclass[10pt]{article}
\usepackage{fontspec,amsmath,amssymb,longtable,geometry,fancyvrb}
\usepackage{unicode-math}
\setmainfont{DejaVu Serif}
\setmathfont{Latin Modern Math}
\geometry{a4paper,margin=20mm}
\allowdisplaybreaks
\setlength{\emergencystretch}{3em}
\title{Álgebra 1.4: soluciones y demostraciones}
\author{Aula de matrices · sección independiente}
\date{}
\begin{document}\maketitle\tableofcontents
'''
for d in D:
 tex+='\n\\clearpage\\section{'+esc(d['id']+'. '+d['title'])+'}\n'+esc(d['statement'])+'\n'
 for mat in d['matrices']:tex+='\\noindent '+esc(mat['name'])+'\\['+mat['tex']+'\\]\n'
 if d.get('note'):tex+='\\textbf{Nota editorial:} '+esc(d['note'])+'\n'
 if d.get('proof'):
  for k,label in [('hypotheses','Hipótesis'),('thesis','Tesis'),('idea','Idea')]:tex+='\\paragraph{'+label+'} '+esc(d['proof'][k])+'\n'
 for s in d['steps']:tex+=latex_step(s)
 tex+='\\subsection*{Conclusión}\n'+esc(d['answer'])+'\n'
 if d.get('examples'):
  tex+='\\subsection*{Ilustraciones: no sustituyen la prueba general}\n'
  for s in d['examples']:tex+=latex_step(s)
 if d.get('matlab'):tex+='\\subsection*{Código MATLAB}\n\\begin{Verbatim}[fontsize=\\small]\n'+d['matlab']['code']+'\\end{Verbatim}\n'
tex+='\\end{document}\n';(DEST/'Coleccion_1_4.tex').write_text(tex)
(DEST/'indice_documentos.json').write_text(json.dumps({'paginas_generales':len(book),'inicio':starts,'individuales':counts},ensure_ascii=False,indent=2));print('Colección:',len(book),'páginas;',round((R/'Coleccion_1_4.pdf').stat().st_size/1048576,2),'MiB')
