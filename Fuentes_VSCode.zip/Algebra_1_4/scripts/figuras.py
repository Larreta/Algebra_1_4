"""Figuras exactas de referencia para la edición impresa. La web usa Plotly por pasos."""
from pathlib import Path
import json,io
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from sympy import sympify
R=Path(__file__).resolve().parents[1];D=json.loads((R/'lecciones.json').read_text());out={}
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#34433c','text.color':'#34433c','axes.edgecolor':'#61716b','grid.color':'#e0e7e1','svg.fonttype':'none'})
colors=['#237344','#bc651e','#7350a3','#277a99','#b53a65','#66613b','#7664bf','#348976','#98534b']
for d in D:
 g=d.get('graph')
 if not g:continue
 kind=g['kind'];fig=plt.figure(figsize=(6.2,3.5));ax=fig.add_subplot(111,projection='3d' if kind=='vector3' else None)
 if kind=='markov':
  A=np.array([[float(sympify(s)) for s in row] for row in d['matrices'][0]['rows']]);x=np.array([float(sympify(row[0])) for row in d['matrices'][1]['rows']]);pts=[x]
  for k in range(20):x=A@x;pts.append(x)
  pts=np.array(pts)
  for j,name in enumerate(g['labels']):ax.plot(range(21),pts[:,j],'-o',ms=2.5,label=name,color=colors[j])
  ax.set(xlabel='Años',ylabel='Proporción del mercado',ylim=(0,1));ax.set_yticks(np.arange(0,1.01,.2));ax.set_xticks(range(0,21,4));ax.legend()
 elif kind=='vector2':
  for v,name,col in [([1,1],'x (dato)',colors[1]),([3,3],'Ax = 3x',colors[0])]:ax.annotate('',xy=v,xytext=(0,0),arrowprops=dict(arrowstyle='->',color=col,lw=2));ax.plot(*v,'o',color=col,label=name)
  ax.set(xlim=(-1,4),ylim=(-1,4),xlabel='x',ylabel='y');ax.set_xticks(range(-1,5));ax.set_yticks(range(-1,5));ax.set_aspect('equal');ax.legend()
 elif kind=='vector3':
  v=np.array([-2,1,-1]);
  for q,name,col in [(v,'A',colors[1]),(v/np.sqrt(6),'k positivo',colors[0]),(-v/np.sqrt(6),'k negativo',colors[2])]:ax.quiver(0,0,0,*q,color=col,label=name)
  ax.set(xlabel='x',ylabel='y',zlabel='z',xlim=(-3,3),ylim=(-3,3),zlim=(-3,3));ax.legend(loc='upper right')
 elif kind=='rotation':
  t=np.linspace(0,2*np.pi,200);ax.plot(np.cos(t),np.sin(t),':',color='#a7b7af')
  for k in range(9):v=np.array([np.cos(k*np.pi/6),-np.sin(k*np.pi/6)]);ax.plot([0,v[0]],[0,v[1]],color=colors[k%9],lw=1.5);ax.text(v[0]*1.1,v[1]*1.1,str(k),fontsize=8)
  ax.set(xlabel='x',ylabel='y',xlim=(-1.4,1.4),ylim=(-1.4,1.4),title='Ejemplo: θ = 30°, giros horarios numerados');ax.set_aspect('equal');ax.set_xticks(np.arange(-1,1.01,.5));ax.set_yticks(np.arange(-1,1.01,.5))
 elif kind=='affine':
  x=np.linspace(-2,4,100);ax.plot(x,2-x,color=colors[0],label='x + y = 2')
  for t in [-1,0,.5,1,2]:q=np.array([2*(1-t),2*t]);ax.plot(*q,'o',color=colors[1]);ax.annotate('t='+str(t),q,xytext=(5,5),textcoords='offset points',fontsize=8)
  ax.set(xlabel='x',ylabel='y',xlim=(-2.6,4.6),ylim=(-2.6,4.6));ax.set_aspect('equal');ax.set_xticks(range(-2,5));ax.set_yticks(range(-2,5));ax.legend()
 elif kind=='powers':
  A=np.array([[float(sympify(s)) for s in row] for row in d['matrices'][0]['rows']]);P=np.eye(len(A));pts=[]
  for k in range(1,13):P=P@A;pts.append(P.copy())
  pts=np.array(pts)
  for i in range(len(A)):
   for j in range(len(A)):ax.plot(range(1,13),pts[:,i,j],'-o',ms=2,label=f'({i+1},{j+1})',color=colors[(i*len(A)+j)%9])
  ax.set(xlabel='Exponente k',ylabel='Valor de la entrada');ax.set_xticks(range(1,13));ax.legend(ncol=3,fontsize=8)
 else:plt.close(fig);continue
 ax.grid(alpha=.7);fig.tight_layout();stream=io.StringIO();fig.savefig(stream,format='svg',bbox_inches='tight');out[d['key']]=stream.getvalue().split('</metadata>')[-1] if False else stream.getvalue()[stream.getvalue().index('<svg'):];plt.close(fig)
(R/'descargas/figuras.json').write_text(json.dumps(out,ensure_ascii=False));print(len(out),'figuras impresas')
