"""Publicación plana y proyecto independiente; comprueba tamaño e identidad de descargas."""
from pathlib import Path
import sys,json,base64,hashlib,zipfile,shutil,re,tempfile,subprocess
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));from build import page
D=json.loads((ROOT/'lecciones.json').read_text());OUT=ROOT.parent/'Publicacion_Algebra_1_4';OUT.mkdir(exist_ok=True)
def b64(p):return base64.b64encode(p.read_bytes()).decode()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def zipfiles(dest,pairs):
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for file,name in pairs:z.write(file,name)
matzip=ROOT/'descargas/Codigos_MATLAB.zip';zipfiles(matzip,[(p,p.name) for p in sorted((ROOT/'matlab').glob('*.m'))])
manifest={'general':{'url':'Coleccion_1_4.pdf','name':'Coleccion_1_4.pdf'},'exercises':{}};bundles=[];payload={};size=0;hashes={}
def flush():
 global payload,size
 if not payload:return
 name='pdfs_1_4_'+str(len(bundles)+1).zfill(2)+'.js';(OUT/name).write_text('window.ALGEBRA14_FILES=window.ALGEBRA14_FILES||{};window.ALGEBRA14_FILES['+json.dumps(name)+']='+json.dumps(payload,separators=(',',':'))+';\n');bundles.append(name);payload={};size=0
for d in D:
 file=ROOT/'descargas'/(d['key']+'.pdf');enc=b64(file)
 if size+len(enc)>5*1024*1024:flush()
 bundle='pdfs_1_4_'+str(len(bundles)+1).zfill(2)+'.js';entry=file.name;payload[entry]=enc;size+=len(enc);manifest['exercises'][d['key']]={'file':bundle,'entry':entry,'name':'Ejercicio_'+d['id'].replace('.','_')+'_Seccion_1_4.pdf'};hashes[entry]={'sha256':digest(file),'bytes':file.stat().st_size}
flush();resources={'Codigos_MATLAB.zip':b64(matzip),'Coleccion_1_4.tex':b64(ROOT/'descargas/Coleccion_1_4.tex')};name='recursos_1_4.js';(OUT/name).write_text('window.ALGEBRA14_FILES=window.ALGEBRA14_FILES||{};window.ALGEBRA14_FILES['+json.dumps(name)+']='+json.dumps(resources,separators=(',',':'))+';\n')
manifest['matlab']={'file':name,'entry':'Codigos_MATLAB.zip','type':'application/zip'};manifest['latex']={'file':name,'entry':'Coleccion_1_4.tex','type':'text/plain'}
(ROOT/'descargas/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));page(D)
for name in ['index.html','Coleccion_1_4.pdf','Guia_1_4.pdf','LEEME.md','REVISION.md']:shutil.copy2(ROOT/name,OUT/name)
(OUT/'.nojekyll').write_text('')
# Índice plano para publicar: un nombre por línea, instrucciones sin carpetas manuales.
public_names=sorted(['index.html','Coleccion_1_4.pdf','Guia_1_4.pdf','LEEME.md','REVISION.md','.nojekyll','Fuentes_VSCode.zip','ARCHIVOS_GITHUB.txt',*bundles,'recursos_1_4.js'])
(OUT/'ARCHIVOS_GITHUB.txt').write_text('SUBE ESTOS ARCHIVOS EN LA RAÍZ DEL REPOSITORIO NUEVO, UNO POR SUBIDA Y COMMIT.\nNo extraigas Fuentes_VSCode.zip para publicar. No subas el ZIP exterior como sustituto de index.html.\n\n'+'\n'.join(public_names)+'\n')
(ROOT/'tests/huellas_pdfs.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2))
# Proyecto editable: descargas físicas para no duplicarlas en bloques JS dentro del código fuente.
with tempfile.TemporaryDirectory(prefix='algebra14-fuentes-') as temp:
 source=Path(temp)/'Algebra_1_4';source.mkdir()
 for name in ['motor','scripts','matlab','vendor','tests']:
  shutil.copytree(ROOT/name,source/name,ignore=shutil.ignore_patterns('__pycache__','*.png','*.pyc','resultados_descargas.json','resultados_empaquetado.json'))
 for name in ['build.py','lecciones.json','requirements.txt','package.json','LEEME.md','REVISION.md','DESARROLLO.md','Coleccion_1_4.pdf','Guia_1_4.pdf']:shutil.copy2(ROOT/name,source/name)
 (source/'descargas').mkdir()
 for p in (ROOT/'descargas').iterdir():
  if p.suffix=='.pdf' and p.name!='portada_indice.pdf' or p.name in ['Coleccion_1_4.tex','Codigos_MATLAB.zip','figuras.json','indice_documentos.json']:shutil.copy2(p,source/'descargas'/p.name)
 direct={'general':{'url':'Coleccion_1_4.pdf'},'exercises':{d['key']:{'url':'descargas/'+d['key']+'.pdf','name':'Ejercicio_'+d['id'].replace('.','_')+'.pdf'} for d in D},'matlab':{'url':'descargas/Codigos_MATLAB.zip'},'latex':{'url':'descargas/Coleccion_1_4.tex'}}
 (source/'descargas/manifest.json').write_text(json.dumps(direct));(source/'.nojekyll').write_text('')
 # Generador en la copia temporal, sin cambiar los bytes de los PDF ya calculados.
 subprocess.run([sys.executable,str(source/'build.py')],check=True,stdout=subprocess.DEVNULL)
 # En el proyecto fuente el ZIP se obtiene al publicar; explicar ese enlace si se consulta localmente.
 s=(source/'index.html').read_text().replace('href="Fuentes_VSCode.zip" download','href="DESARROLLO.md"');(source/'index.html').write_text(s)
 zipfiles(OUT/'Fuentes_VSCode.zip',[(p,str(p.relative_to(Path(temp)))) for p in source.rglob('*') if p.is_file()])
for name in public_names:
 p=OUT/name;assert p.exists(),name;assert p.stat().st_size<25*1024*1024,(name,p.stat().st_size)
# Verificación de todos los bytes empaquetados.
for bundle in bundles:
 s=(OUT/bundle).read_text();encoded=json.loads(s[s.index(']=')+2:].rstrip(';\n'))
 for name,enc in encoded.items():assert hashlib.sha256(base64.b64decode(enc)).hexdigest()==hashes[name]['sha256']
report={'individuales':len(hashes),'hashes_individuales':hashes,'archivos_publicos':{p.name:{'bytes':p.stat().st_size,'sha256':digest(p)} for p in OUT.iterdir() if p.is_file()},'todos_menores_25_MiB':True};(ROOT/'tests/resultados_empaquetado.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
final=ROOT.parent/'Algebra_1_4_GitHub.zip';zipfiles(final,[(OUT/name,name) for name in public_names]);print(json.dumps({'zip':str(final),'MiB':round(final.stat().st_size/1048576,2),'archivos':len(public_names),'mayor_archivo_MiB':round(max((OUT/name).stat().st_size for name in public_names)/1048576,2)},ensure_ascii=False))
