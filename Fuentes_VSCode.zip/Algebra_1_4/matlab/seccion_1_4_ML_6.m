%% Sección 1.4 · ML.6
clear; clc; format rat;
A=[1/2 1/3; 0 -1/5];
for k=1:12, fprintf("A^%d:\n",k); disp(A^k); end
% Compare con la fórmula general demostrada en la lección.
