%% Sección 1.4 · ML.10
clear; clc; format rat;
B=triu(ones(4)); P=eye(4);
for k=1:32
 P=binprod(P,B); fprintf("k=%d\n",k);disp(P);
 if isequal(P,eye(4)),fprintf("Primer retorno: %d\n",k);break;end
end
