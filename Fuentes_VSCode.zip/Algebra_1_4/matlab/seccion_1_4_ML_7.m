%% Sección 1.4 · ML.7
clear; clc; format rat;
A=[1 -2 1;-1 1 2;0 2 1];
AtA=A'*A, AAt=A*A'
B=A+A'; C=A-A'; disp(B); disp(C);
assert(isequal(B',B)); assert(isequal(C',-C));
assert(isequal(B+C,2*A));
