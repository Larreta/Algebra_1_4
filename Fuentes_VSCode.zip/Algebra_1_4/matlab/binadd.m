function C = binadd(A,B)
% Suma en F2: cada entrada se reduce modulo 2.
assert(isequal(size(A),size(B)),'Los tamanos deben coincidir.');
assert(all(A(:)==0 | A(:)==1) && all(B(:)==0 | B(:)==1),'Use bits 0 o 1.');
C = mod(double(A)+double(B),2);
end
