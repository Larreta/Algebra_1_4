%% Sección 1.4 · ML.11
clear; clc; format rat;
B=triu(ones(5)); P=eye(5);
for k=1:32
 P=binprod(P,B); fprintf("k=%d\n",k);disp(P);
 if isequal(P,eye(5)),fprintf("Primer retorno: %d\n",k);break;end
end
