function B = binrand(m,n)
% Matriz m x n de bits equiprobables. Use rng(14) para repetir.
if nargin < 2, n=m; end
B = randi([0 1],m,n);
end
