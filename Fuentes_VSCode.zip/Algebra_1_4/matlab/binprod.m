function C = binprod(A,B)
% Producto matricial en F2; no es el producto entrada a entrada.
assert(size(A,2)==size(B,1),'Dimensiones incompatibles.');
assert(all(A(:)==0 | A(:)==1) && all(B(:)==0 | B(:)==1),'Use bits 0 o 1.');
C = mod(double(A)*double(B),2);
end
