%% Sección 1.4 · ML.9
clear; clc; format rat;
B=triu(ones(3)); P=eye(3);
for k=1:32
 P=binprod(P,B); fprintf("k=%d\n",k);disp(P);
 if isequal(P,eye(3)),fprintf("Primer retorno: %d\n",k);break;end
end
