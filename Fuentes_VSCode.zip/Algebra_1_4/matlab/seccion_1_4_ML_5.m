%% Sección 1.4 · ML.5
clear; clc; format rat;
A=[1 1/2; 0 1/3];
for k=1:12, fprintf("A^%d:\n",k); disp(A^k); end
% Compare con la fórmula general demostrada en la lección.
