%% Sección 1.4 · ML.4
clear; clc; format rat;
A=[.1 .3 .6;.2 .2 .6;.3 .3 .4];
P=(A^2-7*A)*(A+3*eye(3))
Q=(A-eye(3))^2+(A^3+A)
for k=1:8, fprintf("A^%d:\n",k); disp(A^k); end
M=[A'-eye(3);ones(1,3)]; rhs=[zeros(3,1);1];
pi=M\rhs; limite=ones(3,1)*pi'; disp(limite);
assert(norm(pi'*A-pi',1)<1e-12);
