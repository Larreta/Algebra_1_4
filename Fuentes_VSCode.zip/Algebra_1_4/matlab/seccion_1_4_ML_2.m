%% Sección 1.4 · ML.2
clear; clc; format rat;
matrices={tril(ones(5),-1),triu(fix(10*rand(7)),2)};
for inciso=1:2
 A=matrices{inciso}; disp(A); P=eye(size(A));
 for k=1:size(A,1)
  P=P*A; fprintf("k=%d\n",k); disp(P);
  if all(P(:)==0), fprintf("Primer exponente cero: %d\n",k); break; end
 end
end
% En (b), el valor exacto depende de rand; siempre es <=4.
