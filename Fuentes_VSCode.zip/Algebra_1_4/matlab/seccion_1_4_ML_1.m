%% Sección 1.4 · ML.1
clear; clc; format rat;
A=[0 0 1;1 0 0;0 1 0];
for k=1:3, fprintf("A^%d:\n",k); disp(A^k); end
assert(isequal(A^3,eye(3)));
A=[0 1 0 0;-1 0 0 0;0 0 0 1;0 0 1 0];
fprintf("Menor k positivo con A^k=A: 1.\n");
for k=2:5, if isequal(A^k,A), fprintf("Primer retorno con k>1: %d\n",k); break; end; end
