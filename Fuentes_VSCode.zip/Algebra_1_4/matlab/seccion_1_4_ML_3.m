%% Sección 1.4 · ML.3
clear; clc; format rat;
A=[1 -1 0;0 1 -1;-1 0 1];
P=polyvalm([1 -1 1 0 2],A)
Q=polyvalm([1 -3 3 0],A)
assert(isequal(Q,zeros(3)));
