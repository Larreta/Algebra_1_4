%% Sección 1.4 · ML.8
clear; clc; format rat;
B=binrand(3,3); disp(B);
S2=binadd(B,B), S3=binadd(binadd(B,B),B)
assert(isequal(S2,zeros(3)));assert(isequal(S3,B));
for n=1:8
 S=zeros(3);for j=1:n,S=binadd(S,B);end
 fprintf("%d copias:\n",n);disp(S);
end
