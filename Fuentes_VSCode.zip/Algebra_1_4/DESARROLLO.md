# Regeneración y pruebas

La entrega pública usa archivos planos. Este proyecto editable mantiene separados el motor exacto, las lecciones, los controles, los recursos y los documentos.

## Preparación

```bash
python -m pip install -r requirements.txt
npm install
npx playwright install chromium
```

Se necesita Python 3.10 o posterior y Node.js 18 o posterior. El generador de figuras usa además `matplotlib` y `numpy`; el índice y la guía usan `reportlab`. Estas dependencias están en requirements.txt. Para usar un Chromium ya instalado, define `CHROMIUM_PATH` con la ruta real del ejecutable. Si no lo defines, Playwright utiliza su navegador instalado.

## Secuencia

```bash
python build.py
python tests/verificar_matematicas.py
node tests/latex_visual.cjs
python scripts/figuras.py
node scripts/exportar_pdfs.cjs
python scripts/documentos.py
node tests/controles.cjs
python scripts/empaquetar.py
```

`empaquetar.py` reúne el sitio público en la carpeta hermana `Publicacion_Algebra_1_4` y genera `Algebra_1_4_GitHub.zip`. Los informes se conservan en `tests`. Después del empaquetado, `node tests/descargas.cjs` comprueba las descargas sobre esa carpeta pública y bajo una subruta equivalente a GitHub Pages.

El motor usa racionales y expresiones simbólicas exactas; los valores decimales de los gráficos se derivan después. Cada casilla conserva los dos factores de cada pareja, el producto, el acumulado anterior y el siguiente. La interfaz no calcula respuestas por su cuenta: representa ese modelo y mantiene un registro independiente de las casillas que realmente guardó el estudiante.

Los ejercicios teóricos contienen argumentos escritos expresamente. Sus ilustraciones son un campo separado y no reemplazan la prueba. No se generan «pruebas» a partir de unos cuantos ejemplos.

Los PDF individuales incluyen todos los pasos del texto. Para los productos, una tabla compacta conserva cada pareja y cada acumulación. La colección general concatena esos documentos y añade índice y marcadores. Los gráficos estáticos se identifican como referencia final.

El sitio incorpora Plotly, KaTeX, sus fuentes y fflate localmente. Las licencias están en vendor. La página pública integra estos recursos para evitar cargas remotas y errores por carpetas omitidas. Los PDF individuales se distribuyen en bloques de descarga JavaScript; cada bloque reconstruye exactamente los bytes originales al pulsar el botón. El PDF general es un archivo PDF ordinario. No se requiere backend ni Git LFS.

Los códigos MATLAB se suministran con sus auxiliares binarios. Su ejecución requiere MATLAB; la web simula sus operaciones matemáticas sin emular ese programa. La muestra aleatoria de ML.2 es deliberadamente reproducible en el laboratorio; el script MATLAB calcula el índice de la realización que genere `rand`.
